import { AdminGuard } from './user/admin.guard';
import { DashboardComponent } from './dashboard/dashboard/dashboard.component';
import { UsabilityReportComponent } from './usability/usability-report/usability-report.component';
import { SendMessageComponent } from './send-message/send-message.component';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { WelcomeComponent } from './home/welcome.component';
import { WorkitemComponent } from './workitem/workitem.component';
import { WorktypeComponent } from './worktype/worktype.component';
import { PageNotFoundComponent } from './page-not-found.component';
import { AuthGuard } from './user/auth.guard';
import { SelectiveStrategy } from './selective-strategy.service';
import { WorkAssignmentComponent } from './work-assignment/work-assignment.component';
import { TimeSheetComponent } from './time-sheet/time-sheet.component';

@NgModule({
  imports: [
    RouterModule.forRoot([
      { path: 'welcome', component: WelcomeComponent },
      { path: 'workitem', component: WorkitemComponent, canActivate: [AdminGuard] },
      { path: 'worktype', component: WorktypeComponent, canActivate: [AdminGuard] },
      { path: 'sendmessage', component: SendMessageComponent, canActivate: [AuthGuard] },
      { path: 'work-assignment', component: WorkAssignmentComponent, canActivate: [AdminGuard] },
      { path: 'timesheet', component: TimeSheetComponent, canActivate: [AuthGuard] },
      { path: 'timesheet/:id', component: TimeSheetComponent, canActivate: [AuthGuard] },
      { path: 'usabilityReport', component: UsabilityReportComponent, canActivate: [AdminGuard] },
      { path: 'dashboard', component: DashboardComponent , canActivate: [AuthGuard] },
      { path: '', redirectTo: 'welcome', pathMatch: 'full' },
      { path: '**', component: PageNotFoundComponent }
    ], { preloadingStrategy: SelectiveStrategy })   // , { enableTracing: true, preloadingStrategy: SelectiveStrategy }
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
