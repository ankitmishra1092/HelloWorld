import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../user/auth.service';
import { WorktypeService } from './worktype.service';
import { WorkType } from './../shared/models/workType';

@Component({
  selector: 'pm-worktype',
  templateUrl: './worktype.component.html',
  styleUrls: ['./worktype.component.css']
})
export class WorktypeComponent implements OnInit {

  pageTitle: string = "Create Work Type";
  workTypeFormGroup: FormGroup;
  submitted: boolean = false;
  existingWorkTypes: WorkType[];
  errorMessage: string;
  workType: WorkType;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private authenticationService: AuthService,
    private workTypeService: WorktypeService
  ) {
    // redirect to home if already logged in
    if (!this.authenticationService.isLoggedIn) {
      this.router.navigate(['/login']);
    }
  }

  ngOnInit(): void {
    this.workTypeFormGroup = this.formBuilder.group({
      typeCode: ['', Validators.required],
      workTypeDescription: ['', Validators.required]
    });

    this.getExistingWorkTypes();

  }

  // convenience getter for easy access to form fields
  get control() { return this.workTypeFormGroup.controls; }

  private getExistingWorkTypes() {
    this.workTypeService.getWorkTypes().subscribe(
      wts => {
        this.existingWorkTypes = wts;
      });
  }

  CreateWorkType() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.workTypeFormGroup.invalid) {
      return;
    }

    if (!this.existingWorkTypes) {
      this.getExistingWorkTypes();
    }

    if (this.existingWorkTypes && this.existingWorkTypes.find(wt => wt.workTypeCode === this.workTypeFormGroup.value.typeCode)) {
      this.errorMessage = "Please enter a different Work Type Code.";
      return;
    }

    this.workType = {
      id : 0,
      workTypeCode : this.workTypeFormGroup.value.typeCode,
      workTypeDescription : this.workTypeFormGroup.value.workTypeDescription
    };

    this.workTypeService.createWorkType(this.workType).subscribe({
      next : () => this.router.navigate(['/dashboard']),
      error : err => this.errorMessage = err
    });

  }

}
