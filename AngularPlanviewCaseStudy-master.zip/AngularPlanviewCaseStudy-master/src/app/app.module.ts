import { TimeSheetModule } from './time-sheet/time-sheet.module';
import { LoggingInterceptor } from './shared/logging.interceptor';
import { MaterialModule } from './material/material.module';
import { DummyData } from './dummyDataBase';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { DatePipe, CommonModule } from '@angular/common';


// Imports for loading & configuring the in-memory web api
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './home/welcome.component';
import { PageNotFoundComponent } from './page-not-found.component';

/* Feature Modules */
import { UserModule } from './user/user.module';
import { MessageModule } from './messages/message.module';

import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { WorktypeComponent } from './worktype/worktype.component';
import { WorkitemComponent } from './workitem/workitem.component';

//Services
import { WorkitemService } from './workitem/workitem.service';
import { WorktypeService } from './worktype/worktype.service';
import { DashboardModule } from './dashboard/dashboard.module';
import { SendMessageComponent } from './send-message/send-message.component';
import { WorkAssignmentComponent } from './work-assignment/work-assignment.component';
import { UsabilityReportComponent } from './usability/usability-report/usability-report.component';
import { TimeSheetComponent } from './time-sheet/time-sheet.component';

@NgModule({
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    CommonModule,
    HttpClientModule,
    InMemoryWebApiModule.forRoot(DummyData, { delay: 1000 }),
    UserModule,
    MessageModule,
    AppRoutingModule,
    MaterialModule,
    DashboardModule,
    TimeSheetModule,
    ReactiveFormsModule,
    FormsModule,
  ],
  declarations: [
    AppComponent,
    WelcomeComponent,
    PageNotFoundComponent,
    WorktypeComponent,
    WorkitemComponent,
    SendMessageComponent,
    WorkAssignmentComponent,
    UsabilityReportComponent
  ],
  providers : [
    { provide: HTTP_INTERCEPTORS, useClass: LoggingInterceptor, multi: true },
    WorktypeService,
    DatePipe,
    WorkitemComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
