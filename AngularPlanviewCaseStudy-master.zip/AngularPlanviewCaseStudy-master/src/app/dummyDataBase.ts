import { ApiLog } from './shared/models/apilog';
import { User } from './shared/models/user';
import { WorkItem } from './shared/models/workitem';
import { WorkType } from './shared/models/worktype';
import { Message } from './shared/models/message';
import { TimeSheet } from './shared/models/timesheet';
import { InMemoryDbService } from 'angular-in-memory-web-api';

export class DummyData implements InMemoryDbService {

  createDb() {
    const users: User[] = [
      {
        id: 1,
        userName: 'adminuser',
        password: 'Password1',
        firstName: 'Ajay',
        lastName: 'Shah',
        dob: '01-01-1994',
        email: 'AdminUser@gmail.com',
        address1: 'Address Line 1',
        address2: 'Address Line 2',
        city: 'Gurgaon',
        state: 'Haryana',
        country: 'India',
        zip: '147001',
        isAdmin: true,
        UserState: 'Active',
        incorrectPasswordCount: 0,
        assignedWorkItems: ['1111', '2222']
      },
      {
        id: 2,
        userName: 'appuser',
        password: 'Password2',
        firstName: 'Anshul',
        lastName: 'Garg',
        dob: '01-01-1990',
        email: 'appuser@gmail.com',
        address1: 'Address Line 1',
        address2: 'Address Line 2',
        city: 'Gurgaon',
        state: 'Haryana',
        country: 'India',
        zip: '147002',
        isAdmin: false,
        UserState: 'Active',
        incorrectPasswordCount: 0,
        assignedWorkItems: ['3333', '4444']
      },
      {
        id: 3,
        userName: 'sajal',
        password: 'Password1',
        firstName: 'Sajal',
        lastName: 'Gupta',
        dob: '01-01-1990',
        email: 'appuser@gmail.com',
        address1: 'Address Line 1',
        address2: 'Address Line 2',
        city: 'Gurgaon',
        state: 'Haryana',
        country: 'India',
        zip: '147002',
        isAdmin: false,
        UserState: 'Locked',
        incorrectPasswordCount: 3,
        assignedWorkItems: ['3333', '4444']
      }
    ];
    const workItems: WorkItem[] = [
      {
        id: 1,
        workItemCode: '1111',
        workItemDescription: 'Coding',
        workTypeCode: '12121'
      },
      {
        id: 2,
        workItemCode: '2222',
        workItemDescription: 'Unit Testing',
        workTypeCode: '12121'
      },
      {
        id: 3,
        workItemCode: '3333',
        workItemDescription: 'Performance Integration',
        workTypeCode: '12121'
      },
      {
        id: 4,
        workItemCode: '4444',
        workItemDescription: 'Architecture Design',
        workTypeCode: '12121'
      }
    ];
    const workTypes: WorkType[] = [
      {
        id: 1,
        workTypeCode: '12121',
        workTypeDescription: 'Angular Projects'

      },
      {
        id: 2,
        workTypeCode: '12131',
        workTypeDescription: 'Performance Improvement Projects'

      }
    ];

    const messages: Message[] = [
      {
        id: 1,
        from: 'SenderEmail1@gmail.com',
        to: 'AdminUser@gmail.com',
        subject: 'New Product Launch',
        date: new Date(),
        content: 'Message Content 1'
      },
      {
        id: 2,
        from: 'SenderEmail2@gmail.com',
        to: 'AdminUser@gmail.com',
        subject: 'Product Release',
        date: new Date(),
        content: 'Message Content 2'
      },
      {
        id: 3,
        from: 'SenderEmail3@gmail.com',
        to: 'AdminUser@gmail.com',
        subject: 'Defect List',
        date: new Date(),
        content: 'Message Content 3'
      },
      {
        id: 4,
        from: 'SenderEmail4@gmail.com',
        to: 'appuser@gmail.com',
        subject: 'L n P Testing Results',
        date: new Date(),
        content: 'Message Content 4'
      },
      {
        id: 5,
        from: 'SenderEmail5@gmail.com',
        to: 'AdminUser@gmail.com',
        subject: 'TFS Defect estimation',
        date: new Date(),
        content: 'Message Content 5'
      },
      {
        id: 6,
        from: 'SenderEmail6@gmail.com',
        to: 'appuser@gmail.com',
        subject: 'Good Job Team',
        date: new Date(),
        content: 'Message Content 6'
      },
      {
        id: 7,
        from: 'SenderEmail7@gmail.com',
        to: 'appuser@gmail.com',
        subject: 'Sprint Planning',
        date: new Date(),
        content: 'Message Content 7'
      }
    ];

    const apilogs: ApiLog[] = [
      {
        id: 1,
        apiName: 'user',
        url: 'api/user',
        userName: 'Dummy User',
        timestamp: new Date(),
        count: 2
      },
      {
        id: 2,
        apiName: 'message',
        url: 'api/message',
        userName: 'Dummy User',
        timestamp: new Date(),
        count: 3
      },
      {
        id: 3,
        apiName: 'user',
        url: 'api/user',
        userName: 'Real User',
        timestamp: new Date(),
        count: 1
      }
    ];

    const timeSheets: TimeSheet[] = [
      {
        id: 1000001,
        startDate: new Date("07/26/2020"),
        endDate: new Date("07/31/2020"),
        isSubmitted: true,
        timeEntry: [
          {
            id: 1,
            date: new Date("07/26/2020"),
            hours: 8,
            workItem: "1111"
          },
          {
            id: 2,
            date: new Date("07/27/2020"),
            hours: 8,
            workItem: "1111"
          }
        ],
        userId: 1
      },
      {
        id: 1000003,
        startDate: new Date("07/19/2020"),
        endDate: new Date("07/25/2020"),
        isSubmitted: false,
        timeEntry: [
          {
            id: 1,
            date: new Date("07/19/2020"),
            hours: 8,
            workItem: "1111"
          },
          {
            id: 2,
            date: new Date("07/20/2020"),
            hours: 8,
            workItem: "1111"
          }
        ],
        userId: 1
      },
      {
        id: 1000002,
        startDate: new Date("07/19/2020"),
        endDate: new Date("07/25/2020"),
        isSubmitted: true,
        timeEntry: [
          {
            id: 1,
            date: new Date("07/19/2020"),
            hours: 8,
            workItem: "3333"
          },
          {
            id: 2,
            date: new Date("07/20/2020"),
            hours: 8,
            workItem: "3333"
          }
        ],
        userId: 2
      }
    ];

    return { users, workItems, workTypes, messages, apilogs, timeSheets };
  }
}
