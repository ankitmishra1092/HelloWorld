import { UserService } from './user.service';
import { Injectable } from '@angular/core';

import { User } from '../shared/models/user';
import { MessageService } from '../messages/message.service';
import { first } from 'rxjs/operators';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  currentUser: User;
  invalidPasswordUser: User;
  redirectUrl: string;

  get isLoggedIn(): boolean {
    return !!this.currentUser;
  }

  get loggedInUser(): User {
    return this.currentUser;
  }

  get isUserLocked(): boolean {
    return ((!!this.invalidPasswordUser && this.invalidPasswordUser.incorrectPasswordCount >= 3)
            || (this.currentUser && this.currentUser.incorrectPasswordCount >= 3));
  }

  get isAdminUser(): boolean {
    return !!this.currentUser && this.currentUser.isAdmin;
  }

  constructor(private messageService: MessageService,
              private userService: UserService) { }

  login(userName: string, password: string): Observable<boolean> {
    return new Observable(observer => {
      this.userService.getUsers()
            .pipe(first())
            .subscribe(
                users => {
                    this.currentUser = users.find(x => x.userName === userName && x.password === password);

                    if (!!!this.currentUser){
                      this.invalidPasswordUser = users.find(x => x.userName === userName);
                      if (!!this.invalidPasswordUser){
                        this.updateInvalidPasswordCount(this.invalidPasswordUser);
                      }
                    }
                    if (!!this.currentUser){
                      localStorage.setItem('loggedUserName', this.currentUser.userName);
                      if (this.currentUser?.isAdmin) {
                        this.messageService.addMessage('Admin login');
                      }
                      else{
                        this.messageService.addMessage(`User: ${this.currentUser?.userName} logged in`);
                      }
                    }
                    else{
                      this.messageService.addMessage('Invalid Login');
                    }
                    observer.next(true);
                    observer.complete();
                },
                error => {
                    console.log(error);
                    observer.error(error);
                    observer.complete();
        });
      });
  }

  logout(): void {
    this.currentUser = null;
    localStorage.clear();
  }

  updateInvalidPasswordCount(user: User): void{
    user.incorrectPasswordCount += 1;
    this.userService.updateUser(user)
            .pipe(first())
            .subscribe(
                data => {
                  console.log();
                },
                error => {
                    console.log(error);
        });
  }
}
