import { Message } from 'src/app/shared/models/message';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MessageService } from 'src/app/messages/message.service';
import { first } from 'rxjs/operators';
import { Router } from '@angular/router';

@Component({
  selector: 'pm-forgot-password',
  templateUrl: './forgot-password.component.html'
})
export class ForgotPasswordComponent implements OnInit {
  errorMessage: string;
  message: Message;

  constructor(private messageService: MessageService,
              private router: Router) { }

  ngOnInit(): void {
  }

  generatePassword(forgotPasswordForm: NgForm){
    if (forgotPasswordForm && forgotPasswordForm.valid) {
      const userName = forgotPasswordForm.form.value.userName;
      const email = forgotPasswordForm.form.value.email;

      this.message = {
        id: Math.floor(Math.random() * (100 - 10) + 10),
        from: 'AdminUser@gmail.com',
        to: email,
        subject: 'Password has been Reset',
        content: 'Your Password has been reset. Here is your new password : Password123#',
        date: new Date()
      };
      this.messageService.createMessage(this.message)
            .pipe(first())
            .subscribe(
                data => {
                    this.messageService.addMessage('Password Reset successful');
                    alert('Password Sent to email');
                    this.router.navigate(['/welcome']);
                },
                error => {
                    this.messageService.addMessage(error);
        });
    }
  }

}
