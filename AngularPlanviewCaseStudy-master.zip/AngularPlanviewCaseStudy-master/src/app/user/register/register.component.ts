import { User } from './../../shared/models/user';
import { UserService } from './../user.service';
import { MessageService } from './../../messages/message.service';
import { AuthService } from './../auth.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators, AbstractControl, ValidatorFn, FormArray } from '@angular/forms';
import { debounceTime, first } from 'rxjs/operators';

function emailMatcher(c: AbstractControl): { [key: string]: boolean } | null {
  const emailControl = c.get('email');
  const confirmControl = c.get('confirmEmail');

  if (emailControl.pristine || confirmControl.pristine) {
    return null;
  }

  if (emailControl.value === confirmControl.value) {
    return null;
  }
  return { match: true };
}

function passwordMatcher(c: AbstractControl): { [key: string]: boolean } | null {
  const passwordControl = c.get('password');
  const confirmPasswordControl = c.get('confirmPassword');

  if (passwordControl.pristine || confirmPasswordControl.pristine) {
    return null;
  }

  if (passwordControl.value === confirmPasswordControl.value) {
    return null;
  }
  return { match: true };
}

function dateCheck(c: AbstractControl): { [key: string]: boolean } {
  const value = new Date(c.value);
  return isNaN(value.getTime()) || value <= new Date('01/01/1753')
          || value >= new Date()
        ? {invalidDate: true} : undefined;
}


@Component({
  selector: 'pm-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
    emailMessage: string;
    passwordMessage: string;
    user = new User();

  constructor(
        private formBuilder: FormBuilder,
        private router: Router,
        private authenticationService: AuthService,
        private userService: UserService,
        private messageService: MessageService
  ) {
    // redirect to home if already logged in
    if (this.authenticationService.isLoggedIn) {
      this.router.navigate(['/']);
  }
}

private validationMessages = {
  required: 'Please enter your email address.',
  email: 'Please enter a valid email address.'
};

private passwordValidationMessages = {
  required: 'Please enter your password.',
  email: 'Please enter a valid Password.'
};
  ngOnInit(): void {
      this.registerForm = this.formBuilder.group({
        firstName: ['', [Validators.required, Validators.pattern('^[A-Za-z]+$')]],
        lastName: ['', [Validators.required, Validators.pattern('^[A-Za-z]+$')]],
        emailGroup: this.formBuilder.group({
          email: ['', [Validators.required, Validators.email]],
          confirmEmail: ['', Validators.required],
        }, { validator: emailMatcher }),
        dob: [null, dateCheck],

        address1: ['', Validators.required],
        address2: ['', Validators.required],
        city: ['', [Validators.required, Validators.pattern('^[A-Za-z]+$')]],
        state: ['', [Validators.required, Validators.pattern('^[A-Za-z]+$')]],
        zip: ['', [Validators.required, Validators.pattern('^[0-9]+$')]],
        country: ['', [Validators.required, Validators.pattern('^[A-Za-z]+$')]],
        userId : ['', Validators.required],
        passwordGroup: this.formBuilder.group({
          password: ['', [Validators.required]],
          confirmPassword: ['', Validators.required],
        }, { validator: passwordMatcher })
  });

      const emailControl = this.registerForm.get('emailGroup.email');
      emailControl.valueChanges.pipe(debounceTime(1000)).subscribe(
        value => this.setMessage(emailControl)
      );

      const passwordControl = this.registerForm.get('passwordGroup.password');
      passwordControl.valueChanges.pipe(debounceTime(1000)).subscribe(
        value => this.setPasswordMessage(passwordControl)
      );
  }


    onSubmit(): void {
      this.user = {
        id: Math.floor(Math.random() * (100 - 10) + 10),
        userName: this.registerForm.value.userId,
        password: this.registerForm.value.passwordGroup.password,
        firstName: this.registerForm.value.firstName,
        lastName: this.registerForm.value.lastName,
        dob: this.registerForm.value.dob,
        email: this.registerForm.value.emailGroup.email,
        address1: this.registerForm.value.address1,
        address2: this.registerForm.value.address2,
        city: this.registerForm.value.city,
        state: this.registerForm.value.state,
        country: this.registerForm.value.country,
        zip: this.registerForm.value.zip,
        isAdmin: false,
        UserState: 'Active',
        incorrectPasswordCount: 0,
        assignedWorkItems: ['1', '2', '3']
      };

      this.userService.createUser(this.user)
            .pipe(first())
            .subscribe(
                data => {
                    this.messageService.addMessage('Registration successful');
                    this.router.navigate(['/welcome']);
                },
                error => {
                    this.messageService.addMessage(error);
        });
    }

    setMessage(c: AbstractControl): void {
        this.emailMessage = '';
        if ((c.touched || c.dirty) && c.errors) {
          this.emailMessage = Object.keys(c.errors).map(
            key => this.validationMessages[key]).join(' ');
        }
      }

      setPasswordMessage(c: AbstractControl): void {
        this.passwordMessage = '';
        if ((c.touched || c.dirty) && c.errors) {
          this.passwordMessage = Object.keys(c.errors).map(
            key => this.passwordValidationMessages[key]).join(' ');
        }
      }
}
