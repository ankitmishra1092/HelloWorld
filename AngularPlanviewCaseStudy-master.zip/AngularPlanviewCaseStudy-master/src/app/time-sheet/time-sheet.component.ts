import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../user/auth.service';
import { TimeSheet } from './../shared/models/timesheet';
import { TimeEntry } from './../shared/models/timeentry';
import { TimeSheetService } from './time-sheet.service';
import { DatePipe, WeekDay } from '@angular/common';
import { WorkItem } from '../shared/models/workitem';
import { WorkitemService } from '../workitem/workitem.service'

@Component({
  selector: 'pm-time-sheet',
  templateUrl: './time-sheet.component.html',
  styleUrls: ['./time-sheet.component.css']
})
export class TimeSheetComponent implements OnInit {

  timeSheet: TimeSheet;
  timeEntries: TimeEntry[];
  range: FormGroup;
  submitted: boolean;
  workItems: WorkItem[];
  dates: Date[];
  idCounter: number = 0;
  errorMessage: string;
  id: number;
  private sub: any;

  constructor(
    private formBuilder: FormBuilder,
    private timeSheetService: TimeSheetService,
    private workItemService: WorkitemService,
    private datePipe: DatePipe,
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.initializeTimeSheet(null, null);
  }

  ngOnInit(): void {
    this.sub = this.route.params.subscribe(params => {
      this.id = +params['id']; // (+) converts string 'id' to a number
    });

    this.workItemService.getWorkItems().subscribe(
      workItems => {
        this.workItems = workItems.filter(wi => this.authService.loggedInUser.assignedWorkItems.find(aw => aw == wi.workItemCode));
      });

    this.workItems = this.authService.loggedInUser.assignedWorkItems;
    this.range = this.formBuilder.group({
      start: ['', Validators.required],
      end: ['']
    });

    if (this.id) {
      this.populateTimeSheet(this.id);
    }
    else {
      this.loadTimeSheet();
    }

  }

  get controls() { return this.range.controls; }

  getWorkItem(workItemCode: string): string {
    if (workItemCode) {
      let workItem = this.workItems.find(wi => wi.workItemCode === workItemCode);
      if (workItem) {
        return workItem.workItemCode + " - " + workItem.workItemDescription;
      }
    }
  }

  loadTimeSheet() {
    let endDate = this.range.value.end;
    this.timeSheetService.getTimeSheets().subscribe(
      ts => {
        if (endDate)
          this.range.patchValue({
            end: endDate
          });

        this.timeSheet = ts.find(x =>
          this.authService.loggedInUser.id == x.userId
          && this.datePipe.transform(x.startDate, "dd-MM-yyyy") == this.datePipe.transform(this.range.value.start, "dd-MM-yyyy")
          && this.datePipe.transform(x.endDate, "dd-MM-yyyy") == this.datePipe.transform(endDate, "dd-MM-yyyy"));

        if (this.timeSheet && this.timeSheet.timeEntry && this.timeSheet.timeEntry.length) {
          this.idCounter = this.timeSheet.timeEntry.length;
          this.timeSheet.timeEntry.forEach(te => te.date = new Date(te.date));
        }
        else {
          this.initializeTimeSheet(this.range.value.start, endDate);
        }
      });
  }

  populateTimeSheet(id: number) {
    this.timeSheetService.getTimeSheet(id).subscribe(
      ts => {
        this.range.patchValue({
          start: ts.startDate,
          end: ts.endDate
        });
        this.timeSheet = ts;
      });
  }

  initializeTimeSheet(start: Date, end: Date) {
    this.timeSheet = {
      id: 0,
      startDate: start,
      endDate: end,
      userId: this.authService.loggedInUser.id,
      timeEntry: [],
      isSubmitted: false
    };
  }

  setWeek() {
    var selectedDate = new Date(this.range.value.start);
    var startDate = new Date(selectedDate.setDate(this.range.value.start.getDate() - this.range.value.start.getDay()));
    var endDate = new Date(selectedDate.setDate(startDate.getDate() + 6));
    this.range.setValue({
      start: startDate,
      end: endDate
    });
    this.range.controls['end'].setValue(endDate);
    this.loadTimeSheet();
  }

  onDeleteClicked(timeEntry: TimeEntry) {
    this.timeSheet.timeEntry.splice(timeEntry.id);
  }

  addRow() {
    let timeEntry: TimeEntry = {
      id: this.idCounter++,
      date: new Date(this.range.value.start),
      hours: 0,
      workItem: null
    };

    this.timeSheet.timeEntry.push(timeEntry);

  }

  saveTimeSheetChanges(isSubmit: boolean) {
    this.timeSheet.isSubmitted = isSubmit;
    if (this.timeSheet.id == 0) {
      this.timeSheetService.createTimeSheet(this.timeSheet).subscribe({
        next: () => this.router.navigate(['/dashboard']),
        error: err => this.errorMessage = err
      });
    }
    else {
      this.timeSheetService.updateTimeSheet(this.timeSheet).subscribe({
        next: () => this.router.navigate(['/dashboard']),
        error: err => this.errorMessage = err
      });
    }

  }

}
