import { TimeSheet } from './../shared/models/timesheet';
import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TimeSheetService {
  constructor(private http: HttpClient) { }
  private apiUrl = 'api/timeSheets';

  getTimeSheets(): Observable<TimeSheet[]> {
    return this.http.get<TimeSheet[]>(this.apiUrl)
      .pipe(
        tap(data => console.log(JSON.stringify(data))),
        catchError(this.handleError)
      );
  }

  getTimeSheet(id: number): Observable<TimeSheet> {
    const url = `${this.apiUrl}/${id}`;
    return this.http.get<TimeSheet>(url)
      .pipe(
        tap(data => console.log(JSON.stringify(data))),
        catchError(this.handleError)
      );
  }

  createTimeSheet(timeSheet: TimeSheet): Observable<TimeSheet> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    timeSheet.id = null;
    return this.http.post<TimeSheet>(this.apiUrl, timeSheet, { headers })
      .pipe(
        tap(data => console.log('createTimeSheet: ' + JSON.stringify(data))),
        catchError(this.handleError)
      );
  }

  updateTimeSheet(timeSheet: TimeSheet): Observable<TimeSheet> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    const url = `${this.apiUrl}/${timeSheet.id}`;
    return this.http.put<TimeSheet>(url, timeSheet, { headers })
      .pipe(
        tap(() => console.log('updateTimeSheet')),
        // Return the User on an update
        map(() => timeSheet),
        catchError(this.handleError)
      );
  }

  private handleError(err) {
    // in a real world app, we may send the server to some remote logging infrastructure
    // instead of just logging it to the console
    let errorMessage: string;
    if (err.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      errorMessage = `An error occurred: ${err.error.message}`;
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      errorMessage = `Backend returned code ${err.status}: ${err.body.error}`;
    }
    console.error(err);
    return throwError(errorMessage);
  }}
