import { MaterialModule } from './../material/material.module';
import { AuthGuard } from './../user/auth.guard';
import { TimeSheetComponent } from './time-sheet.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { RouterModule, ActivatedRouteSnapshot } from '@angular/router';
import { CommonModule } from '@angular/common';



@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    RouterModule
  ],
  declarations: [
    TimeSheetComponent
  ]
})
export class TimeSheetModule { }
