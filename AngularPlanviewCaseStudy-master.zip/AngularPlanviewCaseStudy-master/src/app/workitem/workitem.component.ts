import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../user/auth.service';
import { WorkItem } from './../shared/models/workitem';
import { WorkType } from './../shared/models/worktype';
import { WorkitemService } from './workitem.service';
import { WorktypeService } from '../worktype/worktype.service';

@Component({
  selector: 'pm-workitem',
  templateUrl: './workitem.component.html',
  styleUrls: ['./workitem.component.css']
})

export class WorkitemComponent implements OnInit {
  pageTitle: string = "Create Work Item";
  workItemFormGroup: FormGroup;
  submitted: boolean = false;
  existingWorkItems: WorkItem[];
  errorMessage: string;
  workItem: WorkItem;
  selectedWorkType: WorkType;
  workTypes: WorkType[];

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private authenticationService: AuthService,
    private workItemService: WorkitemService,
    private workTypeService: WorktypeService
  ) {
    // redirect to home if already logged in
    if (!this.authenticationService.isLoggedIn) {
      this.router.navigate(['/login']);
    }
  }

  ngOnInit(): void {
    this.workItemFormGroup = this.formBuilder.group({
      itemCode: ['', Validators.required],
      workItemDescription: ['', Validators.required],
      selectedWorkType: ['', Validators.required]
    });

    this.getExistingWorkItems();
    this.getWorkTypes();
  }

  // convenience getter for easy access to form fields
  get control() { return this.workItemFormGroup.controls; }

  private getExistingWorkItems() {
    this.workItemService.getWorkItems().subscribe(
      wis => {
        this.existingWorkItems = wis;
      });
  }

  private getWorkTypes() {
    this.workTypeService.getWorkTypes().subscribe(
      wts => {
        this.workTypes = wts;
      });
  }

  CreateWorkItem() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.workItemFormGroup.invalid) {
      return;
    }

    if (!this.existingWorkItems) {
      this.getExistingWorkItems();
    }

    if (this.existingWorkItems && this.existingWorkItems.find(wt => wt.workItemCode === this.workItemFormGroup.value.itemCode)) {
      this.errorMessage = "Please enter a different Work Type Code.";
      return;
    }

    this.workItem = {
      id: 0,
      workItemCode: this.workItemFormGroup.value.itemCode,
      workItemDescription: this.workItemFormGroup.value.workItemDescription,
      workTypeCode: this.workItemFormGroup.value.selectedWorkType
    };

    this.workItemService.createWorkItem(this.workItem).subscribe({
      next: () => this.router.navigate(['/dashboard']),
      error: err => this.errorMessage = err
    });


  }

}
