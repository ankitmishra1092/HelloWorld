import { Message } from './../shared/models/message';
import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MessageService {

  get messages(): string[] {
    return this._messages;
  }

  constructor(private http: HttpClient) { }
  private _messages: string[] = [];
  isDisplayed = false;
  private apiUrl = 'api/messages';

  addMessage(message: string): void {
    const currentDate = new Date();
    this.messages.unshift(message + ' at ' + currentDate.toLocaleString());
  }

  getMessagesForInbox(): Observable<Message[]> {
    return this.http.get<Message[]>(this.apiUrl)
      .pipe(
        tap(data => console.log(JSON.stringify(data))),
        catchError(this.handleError)
      );
  }

  createMessage(message: Message): Observable<Message> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    //message.id = null;
    return this.http.post<Message>(this.apiUrl, message, { headers })
      .pipe(
        tap(data => console.log('createMessage: ' + JSON.stringify(data))),
        catchError(this.handleError)
      );
  }

  private handleError(err): Observable<any> {
    // in a real world app, we may send the server to some remote logging infrastructure
    // instead of just logging it to the console
    let errorMessage: string;
    if (err.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      errorMessage = `An error occurred: ${err.error.message}`;
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      errorMessage = `Backend returned code ${err.status}: ${err.body.error}`;
    }
    console.error(err);
    return throwError(errorMessage);
  }
}
