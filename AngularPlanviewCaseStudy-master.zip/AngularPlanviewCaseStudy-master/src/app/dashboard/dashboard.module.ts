import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '../material/material.module';
import { SharedModule } from '../shared/shared.module';
import { BrowserModule } from '@angular/platform-browser';

// Import for Split screen
import { AngularSplitModule } from 'angular-split';

import { DashboardComponent } from './dashboard/dashboard.component';
import { InboxComponent } from './inbox/inbox.component';
import { UserBoardComponent } from './user-board/user-board.component';
import { MessageBoxComponent } from './message-box/message-box.component';
import { EditUserComponent } from './edit-user/edit-user.component';



@NgModule({
  declarations: [InboxComponent, UserBoardComponent, DashboardComponent, MessageBoxComponent, EditUserComponent],
  imports: [
    CommonModule,
    MaterialModule,
    RouterModule,
    SharedModule,
    AngularSplitModule.forRoot(),
    BrowserModule
  ],
  exports: [DashboardComponent]
})
export class DashboardModule { }
