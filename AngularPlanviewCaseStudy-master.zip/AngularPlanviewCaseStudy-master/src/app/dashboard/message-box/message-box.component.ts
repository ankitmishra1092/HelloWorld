import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'pm-message-box',
  templateUrl: './message-box.component.html',
  styleUrls: ['./message-box.component.css']
})
export class MessageBoxComponent implements OnInit {

  constructor() { }

  @Input() messageValue: any;

  ngOnInit(): void {
  }

}
