import { MessageService } from './../../messages/message.service';
import { Component, OnInit, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { Message } from 'src/app/shared/models/message';

@Component({
  selector: 'pm-inbox',
  templateUrl: './inbox.component.html',
  styleUrls: ['./inbox.component.css']
})
export class InboxComponent implements OnInit , OnChanges{
  messages: Message[];
  constructor(private ms: MessageService) { }

  @Output() readMessage: EventEmitter <any> = new EventEmitter<number>();

  // messages = [
  //   {
  //     from: 'Entity 1',
  //     subject: 'Message Subject 1',
  //     date: new Date(),
  //     content: 'Message Content 1'
  //   },
  //   {
  //     from: 'Entity 2',
  //     subject: 'Message Subject 2',
  //    date: new Date(),
  //     content: 'Message Content 2'
  //   },
  //    {
  //     from: 'Entity 3',
  //     subject: 'Message Subject 3',
  //     date: new Date(),
  //     content: 'Message Content 3'
  //   },
  //   {
  //     from: 'Entity 4',
  //     subject: 'Message Subject 4',
  //     date: new Date(),
  //     content: 'Message Content 4'
  //   },
  //     {
  //     from: 'Entity 5',
  //     subject: 'Message Subject 5',
  //     date: new Date(),
  //     content: 'Message Content 5'
  //   },
  //  {
  //     from: 'Entity 6',
  //     subject: 'Message Subject 6',
  //     date: new Date(),
  //     content: 'Message Content 6'
  //   },
  //  {
  //     from: 'Entity 7',
  //     subject: 'Message Subject 7',
  //     date: new Date(),
  //     content: 'Message Content 7'
  //   },
  // ];

  ngOnInit(): void {
    this.getInboxItems();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (this.readMessage && this.readMessage.length > 0) {
        this.readMessage.emit(this.readMessage[0]);
       }
  }

  private getInboxItems(): void {
    this.ms.getMessagesForInbox().subscribe(
      wis => {
        this.messages = wis;
      });
  }

  onRowClicked(item): void  {
    console.log(item);
    this.readMessage.emit(item);
    // this.router.navigate([{ outlets: { message: [item] } }]);
  }
}
