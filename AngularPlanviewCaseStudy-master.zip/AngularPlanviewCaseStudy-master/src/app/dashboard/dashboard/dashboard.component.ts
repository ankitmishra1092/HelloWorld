import { Component, OnInit, SimpleChanges } from '@angular/core';
import { SplitComponent, SplitAreaDirective } from 'angular-split';
import { Router } from '@angular/router';

@Component({
  selector: 'pm-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private router: Router) {
}

direction = 'horizontal';
messageValue: any;
  ngOnInit(): void {
  }

displayMessage(data): void{
    this.messageValue = data;
}

}
