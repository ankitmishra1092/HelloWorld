import { TimeSheetService } from './../../time-sheet/time-sheet.service';
import { AuthService } from './../../user/auth.service';
import { UserService } from './../../user/user.service';
import { Component, OnInit } from '@angular/core';
import { first } from 'rxjs/operators';
import { User } from 'src/app/shared/models/user';
import { WorkitemService } from 'src/app/workitem/workitem.service';
import { WorkItem } from 'src/app/shared/models/workitem';
import { TimeSheet } from 'src/app/shared/models/timesheet';
import { MatDialog } from '@angular/material/dialog';
import { EditUserComponent } from '../edit-user/edit-user.component';

@Component({
  selector: 'pm-user-board',
  templateUrl: './user-board.component.html',
  styleUrls: ['./user-board.component.css']
})
export class UserBoardComponent implements OnInit {
  userList: User[];
  workItemList: WorkItem[];
  timeSheets: TimeSheet[];
  isAdminUser: boolean;

  constructor(private userService: UserService,
              private workItemService: WorkitemService,
              private authService: AuthService,
              private timeSheetService: TimeSheetService,
              public dialog: MatDialog ) { }

  panelOpenState = false;

  ngOnInit(): void {
    this.loadUsers();
    this.getWorkItems();
    this.getTimeSheets();
    this.isAdminUser = this.authService.isAdminUser;
  }

  onAddClicked(user): void {
    const dialogRef = this.dialog.open(EditUserComponent, {
      width: '800px',
      data: user
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      var userToUpdate = this.userList.find(us=>us.id === result.id);
      let index = this.userList.indexOf(userToUpdate);
      this.userList[index] = result;
    });
  }

  onDeleteClicked(user: User): void {
    let choice = confirm('Are you sure you want to delete the User');
    if (choice === true) {
      this.userService.deleteUser(user.id)
      .pipe(first())
      .subscribe(
          data => {
            this.loadUsers();
          },
          error => {
              console.log(error);
      });
     } else {
          return;
     }

  }

  onUnlockedlicked(user: User): void {
    user.incorrectPasswordCount = 0;
    if (this.authService.invalidPasswordUser){
      this.authService.invalidPasswordUser.incorrectPasswordCount = 0;
    }
    this.userService.updateUser(user)
            .pipe(first())
            .subscribe(
                data => {
                  alert('User Unlocked');
                },
                error => {
                    console.log(error);
        });
  }

  private loadUsers(): void{
    this.userService.getUsers()
            .pipe(first())
            .subscribe(
                data => {
                    this.userList = data;
                },
                error => {
                    console.log(error);
        });
      }

  private getWorkItems(): void {
    this.workItemService.getWorkItems().subscribe(
      wis => {
        this.workItemList = wis.filter(wi => this.authService.loggedInUser.assignedWorkItems.find(aw => aw === wi.workItemCode));
      });
  }

  private getTimeSheets(): void {
    this.timeSheetService.getTimeSheets().subscribe(
      ts => {
        if (this.authService.loggedInUser.isAdmin){
          this.timeSheets = ts.filter(t => t.isSubmitted);
        }
        else{
          this.timeSheets = ts.filter(t => t.userId === this.authService.loggedInUser.id);
        }
      });
  }

}
