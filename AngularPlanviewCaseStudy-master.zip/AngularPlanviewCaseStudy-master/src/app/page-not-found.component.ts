import { Component } from '@angular/core';

@Component({
  template: `
    <h1 style='  margin-top: 20px;
    margin-left: 20px;
    margin-right: 20px;
    margin-bottom: 1% !important;'>This is not the page you were looking for!</h1>
    `
})
export class PageNotFoundComponent { }
