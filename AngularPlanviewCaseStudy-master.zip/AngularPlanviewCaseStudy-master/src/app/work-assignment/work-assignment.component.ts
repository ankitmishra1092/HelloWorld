import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { WorkItem } from '../shared/models/workitem';
import { Router } from '@angular/router';
import { AuthService } from '../user/auth.service';
import { WorkitemService } from '../workitem/workitem.service';
import { UserService } from '../user/user.service';
import { User } from '../shared/models/user';

@Component({
  selector: 'pm-work-assignment',
  templateUrl: './work-assignment.component.html',
  styleUrls: ['./work-assignment.component.css']
})
export class WorkAssignmentComponent implements OnInit {
  pageTitle: string = "Assign Work Item";
  assignWorkItemFormGroup: FormGroup;
  submitted: boolean = false;
  workItems: WorkItem[];
  users: User[];
  errorMessage: string;
  workItem: WorkItem;
  user: User;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private authenticationService: AuthService,
    private workItemService: WorkitemService,
    private userService: UserService,
  ) {
    // redirect to home if already logged in
    if (!this.authenticationService.isLoggedIn) {
      this.router.navigate(['/login']);
    }
  }

  ngOnInit(): void {
    this.assignWorkItemFormGroup = this.formBuilder.group({
      selectedUser: ['', Validators.required],
      selectedWorkItem: ['', Validators.required]
    });

    this.getExistingWorkItems();
    this.getUsers();
  }

  // convenience getter for easy access to form fields
  get control() { return this.assignWorkItemFormGroup.controls; }

  setWorkItemsAssignedToUser() {
    this.userService.getUser(this.assignWorkItemFormGroup.value.selectedUser).subscribe(
      user => {
        this.assignWorkItemFormGroup.setValue({
          "selectedUser": this.assignWorkItemFormGroup.value.selectedUser,
          "selectedWorkItem": user.assignedWorkItems
        });
      });
  }

  private getExistingWorkItems() {
    this.workItemService.getWorkItems().subscribe(
      wis => {
        this.workItems = wis;
      });
  }

  private getUsers() {
    this.userService.getUsers().subscribe(
      users => {
        this.users = users;
      });
  }

  AssignWorkItems() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.assignWorkItemFormGroup.invalid) {
      return;
    }

    this.userService.getUser(this.assignWorkItemFormGroup.value.selectedUser).subscribe(
      user => {
        user.assignedWorkItems = this.assignWorkItemFormGroup.value.selectedWorkItem;

        this.userService.updateUser(user).subscribe({
          next: () => this.router.navigate(['/dashboard']),
          error: err => this.errorMessage = err
        });
      });

  }

}
