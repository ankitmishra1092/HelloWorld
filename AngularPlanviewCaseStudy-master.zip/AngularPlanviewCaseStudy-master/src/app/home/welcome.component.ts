import { User } from './../shared/models/user';
import { UserService } from './../user/user.service';
import { Component } from '@angular/core';
import { first } from 'rxjs/operators';
import { SplitComponent, SplitAreaDirective } from 'angular-split';
import { Router } from '@angular/router';

@Component({
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent {

  public pageTitle = 'Welcome to TimeSheet Management';
  public usersList: any;

  constructor(private userService: UserService){}

  public loadUsers(): void{
    this.userService.getUsers()
            .pipe(first())
            .subscribe(
                data => {
                    this.usersList = JSON.stringify(data);
                },
                error => {
                    console.log(error);
        });
      }

}
