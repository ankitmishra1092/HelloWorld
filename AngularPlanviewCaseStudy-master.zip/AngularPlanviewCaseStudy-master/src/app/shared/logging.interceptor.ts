import { ApiLog } from './models/apilog';
import { AppLoggerService } from './../usability/app-logger.service';
import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { first } from 'rxjs/operators';

@Injectable()
export class LoggingInterceptor implements HttpInterceptor {
  private apilog: ApiLog;
  constructor(private apiLogService: AppLoggerService) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const userName = localStorage.getItem('loggedUserName');
    if (request.url.match(/api\//g)){
      this.apilog = {
        id: Math.floor(Math.random() * (1000 - 10) + 10),
        apiName: request.url.substr((request.url.indexOf('api') + 4), 10),
        url: request.url,
        userName: !!userName ? userName : 'Anonymous',
        timestamp: new Date(),
        count: 1
      };
      if (this.apilog.apiName != 'apilogs'){
        this.logResponse(this.apilog);
      }
    }

    return next.handle(request);
  }

  private logResponse(apilog: ApiLog): void {
    this.apiLogService.addLog(apilog)
    .pipe(first())
            .subscribe(
                data => {
                    console.log();
                },
                error => {
                    console.log(error);
        });

  }
}
