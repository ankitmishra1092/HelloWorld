/* Defines the message entity */
export class Message {
    id: number;
    from: string;
    to: string;
    subject: string;
    date: Date;
    content: string;
  }
