/* Defines the workitem entity */
export interface WorkItem {
    id: number;
    workItemCode: string;
    workItemDescription: string;
    workTypeCode: string;
  }
  