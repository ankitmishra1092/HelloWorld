/* Defines the message entity */
export class ApiLog {
  id: number;
  userName: string;
  apiName: string;
  url: string;
  timestamp: Date;
  count: number;
}
