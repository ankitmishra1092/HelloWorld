import { WorkItem } from "./workitem"

/* Defines the timeentry entity */
export interface TimeEntry {
    id: number;  
    date: Date;
    workItem: string;
    hours: Number;
  }
  