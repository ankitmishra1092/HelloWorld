/* Defines the user entity */
export class User {
  id: number;
  userName: string;
  password: string;
  firstName: string;
  lastName: string;
  dob: string;
  email: string;
  address1?: string;
  address2?: string;
  city?: string;
  state?: string;
  country?: string;
  zip?: string;
  isAdmin: boolean;
  UserState: string;
  incorrectPasswordCount: number;
  assignedWorkItems?: any[];
}
