/* Defines the workType entity */
export interface WorkType {
    id: number;
    workTypeCode: string;
    workTypeDescription: string;
  }
  