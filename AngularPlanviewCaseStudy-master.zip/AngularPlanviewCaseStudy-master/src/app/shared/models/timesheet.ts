import { TimeEntry } from "./timeentry"

/* Defines the timesheet entity */
export interface TimeSheet {
    startDate: Date,
    endDate: Date,
    userId: Number;
    id: Number;
    timeEntry: TimeEntry[];
    isSubmitted: boolean;
  }
  