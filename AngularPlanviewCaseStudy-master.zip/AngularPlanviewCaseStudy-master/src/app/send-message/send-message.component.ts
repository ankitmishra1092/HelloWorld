import { AuthService } from './../user/auth.service';
import { NgForm } from '@angular/forms';
import { Message } from './../shared/models/message';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MessageService } from '../messages/message.service';
import { first } from 'rxjs/operators';
import { User } from '../shared/models/user';

@Component({
  selector: 'pm-send-message',
  templateUrl: './send-message.component.html',
  styleUrls: ['./send-message.component.css']
})
export class SendMessageComponent implements OnInit {
  model = new Message();
  submitted = false;
  loggedUser: User;
  error: {};

  constructor(private messageService: MessageService,
              private authService: AuthService,
              private router: Router) { }

  ngOnInit(): void {
  }

  onSubmit(sendForm: NgForm) {
    this.submitted = true;
    this.loggedUser = this.authService.loggedInUser;
    this.model.id = Math.floor(Math.random() * (100 - 10) + 10);
    this.model.from = !!this.loggedUser ? this.loggedUser.email : 'SenderUser@gmail.com';
    this.model.date = new Date();
    this.messageService.createMessage(this.model)
          .pipe(first())
          .subscribe(
              data => {
                  this.messageService.addMessage('Message Sent successfully');
                  sendForm.reset();
              },
              error => {
                  this.messageService.addMessage(error);
      });
  }

  gotoHome() {
    this.router.navigate(['/dashboard']);
  }


}
