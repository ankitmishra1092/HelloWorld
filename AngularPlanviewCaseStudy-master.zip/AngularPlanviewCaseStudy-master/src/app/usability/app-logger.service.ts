import { ApiLog } from './../shared/models/apilog';
import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AppLoggerService {

  private apiLogUrl = 'api/apilogs';
  constructor(private http: HttpClient) { }

  getLogs(): Observable<ApiLog[]> {
    return this.http.get<ApiLog[]>(this.apiLogUrl)
      .pipe(
        tap(data => console.log()),
        catchError(this.handleError)
      );
  }

  addLog(apilog: ApiLog): Observable<ApiLog> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post<ApiLog>(this.apiLogUrl, apilog, { headers })
      .pipe(
        tap(data => console.log()),
        catchError(this.handleError)
      );
  }

  private handleError(err) {
    // in a real world app, we may send the server to some remote logging infrastructure
    // instead of just logging it to the console
    let errorMessage: string;
    if (err.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      errorMessage = `An error occurred: ${err.error.message}`;
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      errorMessage = `Backend returned code ${err.status}: ${err.body.error}`;
    }
    console.error(err);
    return throwError(errorMessage);
  }
}
