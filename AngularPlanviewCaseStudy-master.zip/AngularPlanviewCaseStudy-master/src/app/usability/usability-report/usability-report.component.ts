import { AppLoggerService } from './../app-logger.service';
import { ApiLog } from './../../shared/models/apilog';
import { Component, OnInit } from '@angular/core';
import { first, groupBy, mergeMap, toArray } from 'rxjs/operators';


@Component({
  selector: 'pm-usability-report',
  templateUrl: './usability-report.component.html',
  styleUrls: ['./usability-report.component.css']
})
export class UsabilityReportComponent implements OnInit {
  apiLogs: ApiLog[] = [];
  constructor(private apiLoggerService: AppLoggerService) { }

  ngOnInit(): void {
    this.apiLoggerService.getLogs()
            .pipe()
            .subscribe(
                data => {
                    this.apiLogs = this.groupby(data);
        });
  }

  groupby(apilogs: ApiLog[]): ApiLog[] {
    let groupedLogs: ApiLog[] = [];
    for (let log of apilogs) {
      let index = !!groupedLogs && groupedLogs.findIndex(e => e.userName === log.userName && e.apiName === log.apiName);
      let obj = !!groupedLogs && groupedLogs.find(e => e.userName === log.userName && e.apiName === log.apiName);

      if (index === -1) {
        groupedLogs.push(log);
      } else {
        obj.count++;
        groupedLogs[index] = obj;
      }
    }
    return groupedLogs;
  }
}
