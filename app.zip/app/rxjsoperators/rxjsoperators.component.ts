import { Component, OnInit } from '@angular/core';
import { from, of } from 'rxjs';
import { map, take, tap } from "rxjs/operators";

@Component({
  selector: 'app-rxjsoperators',
  templateUrl: './rxjsoperators.component.html',
  styleUrls: ['./rxjsoperators.component.css']
})
export class RxjsoperatorsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    from([2,4,6,8,10,20,30,40]).pipe(
      map( 
        item => item*2 // 2*2 = 4   4*2=8
        ),
      map(
        item => {
        
        if(item >= 50)
        {
          throw new Error('Capacity Exceeded above 50');
        }
        return item*3 //4*3  8*3=24
      }
      ),
      take(15)
    )
    
    .subscribe(
      item => console.log(item),
      error => console.log(error),
      () => console.log('Complete')
      
      ); //12 24
  }

}
