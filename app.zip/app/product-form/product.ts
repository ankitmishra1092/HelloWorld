export interface Product{
    id:number;
    pname:string;
    ptype:string;
    pprice:number
}