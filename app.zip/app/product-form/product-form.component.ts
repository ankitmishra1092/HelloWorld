import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product-form',
  templateUrl: './product-form.component.html',
  styleUrls: ['./product-form.component.css']
})
export class ProductFormComponent implements OnInit {

  products:any;
  productForm:FormGroup;
  product:any;

  constructor(private productService:ProductService,
    private fb:FormBuilder) {
    this.loadProducts();
//Creating Form Builder

this.productForm = this.fb.group({
  id : [''],
  pname : [''],
  ptype : [''],
  pprice : ['']
});
   }

   loadProducts(){
    this.productService.getAllProducts().subscribe(
      (response) => {
        console.log(response);
        this.products = response;
      },
      (error) => {
        console.log(error);
        
      }
    );
   }

   onSubmitClick(data){
     console.log(data);
    this.productService.saveProduct(data).subscribe(
      (response) => {
        // console.log(response);
        this.loadProducts();
      },
      (error) => {}
    );
   }

   LoadProductByID(id){
     console.log(id);
     this.productService.getProductByID(id).subscribe(
       (response) =>{
        this.product = response;
        console.log(this.product);
        this.productForm.patchValue(this.product);

       },
       (error) => {

       }
     );
     

   }

   BuyNow(id,surgeprice) {
     console.log('items purchased at surged price of ' + surgeprice);
     
   }
  ngOnInit(): void {
  }

}
