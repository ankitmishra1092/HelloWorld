import { AfterViewInit, Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-required-validator',
  templateUrl: './required-validator.component.html',
  styleUrls: ['./required-validator.component.css']
})
export class RequiredValidatorComponent implements OnInit,AfterViewInit {

  requiredForm: FormGroup;
  constructor(private fb:FormBuilder) {
   
    this.myForm();
    
   }

   myForm(){
     this.requiredForm = this.fb.group(
       {
         name : ['FISGLObal',Validators.required],
         email : ['FISGLObal',Validators.pattern('/')]
       }
     );
   }

  ngOnInit(): void {
  }

  ngAfterViewInit(): void {
    this.requiredForm.patchValue({
      name : 'FIS SOlutions'
    });
  }


}
