import { Component, OnInit } from '@angular/core';
import { of,from, Observable, interval } from "rxjs";

const secondsCounter = interval(10000);

@Component({
  selector: 'app-rx',
  templateUrl: './rx.component.html',
  styleUrls: ['./rx.component.css']
})
export class RxComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    // of([2,4,6,8,10,12]).subscribe(
    //   item => {
    //     // CHECK DATE N TIME, CHECK IF SURGE PRICING IS APPLICABLE
    //         console.log(item)
    //   },
    //   error => console.log(error),
    //   () => console.log('I Am Done')
    // );

    const subscriptions = secondsCounter.subscribe(
      item => console.log('I Am Emitted ')
    );

    // from([2,4,6,8,10,12]).subscribe(
    //   item => {
    //     // CHECK DATE N TIME, CHECK IF SURGE PRICING IS APPLICABLE
    //         console.log(item * 1.8)
    //   },
    //   error => console.log(error),
    //   () => console.log('I Am Done')
      
    // );

    // of('M1','M2','M3','M4','M5','M6').subscribe(
    //   item => console.log(item),
    //   error => console.log(error),
    //   () => console.log('I Am Done')
    // );


  }

}

// 
const observer = {
  next : nextValue => console.log(nextValue),
  error : err => console.log(err),
  complete : () => console.log('I am Done')
}

const stream = new Observable(
  observer => {
    observer.next();
    observer.error();
    observer.complete();
  }
);