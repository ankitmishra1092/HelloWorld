import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactive',
  templateUrl: './reactive.component.html',
  styleUrls: ['./reactive.component.css']
})
export class ReactiveComponent implements OnInit {

  formdata;

  constructor() { }

  ngOnInit(): void {
    this.formdata = new FormGroup({
      userName : new FormControl("",Validators.required),
      userID : new FormControl(),
    });
  }

  onSubmitClick(data){
    console.log(data);
    
  }
}