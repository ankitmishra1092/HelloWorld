import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { Product } from "./product-form/product";
const BASE_URL:string = "http://localhost:4000/";

@Injectable({ 
  providedIn: 'root'
})
export class ProductService {

  surgeprice = true;
  constructor(private http:HttpClient) { }

  getAllProducts(){
    const URL = BASE_URL + "product";
    return this.http.get(URL);
  }

  saveProduct(productPayload) {
    const URL = BASE_URL + "product";
    return this.http.post(URL,productPayload);
  }

  getProductByID(id){
    const URL = BASE_URL + "product/" + id;
    let surgeprice = false;
    return this.http.get<Product>(URL).pipe(
      map(
        product => {
          if (surgeprice == true) {  //any criteria
          product.pprice = product.pprice *4;
          return product
        }
        return product
        }
      )
    );
  }

  private extractData(res:Response){
    const body = res.json();
    return body || {};
  }


  getHttpOptions(){
    return { headers: new HttpHeaders(
      {
        'Content-Type' : 'application/json',
        'Cache-Control' : 'no-cache',
      }
    ) }
  }

}
