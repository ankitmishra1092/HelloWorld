import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TemplateDrivenComponent } from './template-driven/template-driven.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ReactiveComponent } from './reactive/reactive.component';
import { RequiredValidatorComponent } from './required-validator/required-validator.component';
import { ProductFormComponent } from './product-form/product-form.component';
import { HttpClientModule } from "@angular/common/http";
import { ProductService } from './product.service';
import { RxComponent } from './rx/rx.component';
import { RxjsoperatorsComponent } from './rxjsoperators/rxjsoperators.component';
@NgModule({
  declarations: [
    AppComponent,
    TemplateDrivenComponent,
    ReactiveComponent,
    RequiredValidatorComponent,
    ProductFormComponent,
    RxComponent,
    RxjsoperatorsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
