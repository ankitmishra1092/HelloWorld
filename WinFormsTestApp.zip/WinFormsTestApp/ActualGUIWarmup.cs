﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/// <summary>
/// Inclusion of PEAK PCAN-Basic namespace
/// </summary>
using Peak.Can.Basic;
using TPCANHandle = System.UInt16;
using TPCANBitrateFD = System.String;
using TPCANTimestampFD = System.UInt64;
using Peak.Can.Basic.BackwardCompatibility;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Security.Authentication.ExtendedProtection;

namespace WinFormsTestApp
{
    public partial class ActualGUIWarmup : Form
    {

        #region Delegates
        /// <summary>
        /// Read-Delegate Handler
        /// </summary>
        private delegate void ReadDelegateHandler();
        #endregion


        #region Members
        /// <summary>
        /// Saves the desired connection mode
        /// </summary>
        private bool m_IsFD;
        /// <summary>
        /// Saves the handle of a PCAN hardware
        /// </summary>
        private TPCANHandle m_PcanHandle;
        /// <summary>
        /// Saves the baudrate register for a conenction
        /// </summary>
        private TPCANBaudrate m_Baudrate;
        /// <summary>
        /// Saves the type of a non-plug-and-play hardware
        /// </summary>
        private TPCANType m_HwType;
        /// <summary>
        /// Stores the status of received messages for its display
        /// </summary>
        private System.Collections.ArrayList m_LastMsgsList;
        /// <summary>
        /// Read Delegate for calling the function "ReadMessages"
        /// </summary>
        private ReadDelegateHandler m_ReadDelegate;
        /// <summary>
        /// Receive-Event
        /// </summary>
        private System.Threading.AutoResetEvent m_ReceiveEvent;
        /// <summary>
        /// Thread for message reading (using events)
        /// </summary>
        private System.Threading.Thread m_ReadThread;
        /// <summary>
        /// Handles of non plug and play PCAN-Hardware
        /// </summary>
        private TPCANHandle[] m_NonPnPHandles;
        #endregion

        public ActualGUIWarmup()
        {
            InitializeComponent();
            // Initializes specific components
            //
            InitializeBasicComponents();
        }

        /// <summary>
        /// Initialization of PCAN-Basic components
        /// </summary>
        private void InitializeBasicComponents()
        {
            bindLeftTree();
            fillAvailableChannels();
           // removeControls();
        }

       protected void removeControls()
        {
            foreach (Control item in panel1.Controls)
            {
                panel1.Controls.Remove(item);
            }
            ActualGUIWarmup  obj = new ActualGUIWarmup();
            obj.Controls.Remove(panel1);
        }

        private void fillAvailableChannels()
        {
            TPCANStatus stsResult;
            uint iChannelsCount;
            bool bIsFD;

            // Clears the Channel comboBox and fill it again with 
            // the PCAN-Basic handles for no-Plug&Play hardware and
            // the detected Plug&Play hardware
            //
            listBox1.Items.Clear();
            try
            {

                // Checks for available Plug&Play channels
                //
                stsResult = PCANBasic.GetValue(PCANBasic.PCAN_NONEBUS, TPCANParameter.PCAN_ATTACHED_CHANNELS_COUNT, out iChannelsCount, sizeof(uint));
                if (stsResult == TPCANStatus.PCAN_ERROR_OK)
                {

                    TPCANChannelInformation[] info = new TPCANChannelInformation[iChannelsCount];

                    stsResult = PCANBasic.GetValue(PCANBasic.PCAN_NONEBUS, TPCANParameter.PCAN_ATTACHED_CHANNELS, info);
                    if (stsResult == TPCANStatus.PCAN_ERROR_OK)
                        // Include only connectable channels
                        //
                        foreach (TPCANChannelInformation channel in info)
                            if ((channel.channel_condition & PCANBasic.PCAN_CHANNEL_AVAILABLE) == PCANBasic.PCAN_CHANNEL_AVAILABLE)
                            {
                                bIsFD = (channel.device_features & PCANBasic.FEATURE_FD_CAPABLE) == PCANBasic.FEATURE_FD_CAPABLE;
                                //MessageBox.Show("channel.channel_handle=" + channel.channel_handle);
                                listBox1.Items.Add(FormatChannelName(channel.channel_handle, bIsFD));
                                bindLeftSubMeu(FormatChannelName(channel.channel_handle, bIsFD));
                                treeView1.Nodes[0].Nodes[0].Nodes.Add(FormatChannelName(channel.channel_handle, bIsFD));
                            }
                }


                if (stsResult != TPCANStatus.PCAN_ERROR_OK)
                    MessageBox.Show(GetFormatedError(stsResult));
            }
            catch (DllNotFoundException)
            {
                MessageBox.Show("Unable to find the library: PCANBasic.dll !", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(-1);
            }
        }

        /// <summary>
        /// Gets the formated text for a PCAN-Basic channel handle
        /// </summary>
        /// <param name="handle">PCAN-Basic Handle to format</param>
        /// <param name="isFD">If the channel is FD capable</param>
        /// <returns>The formatted text for a channel</returns>
        private string FormatChannelName(TPCANHandle handle, bool isFD)
        {
            TPCANDevice devDevice;
            byte byChannel;

            // Gets the owner device and channel for a 
            // PCAN-Basic handle
            //
            if (handle < 0x100)
            {
                devDevice = (TPCANDevice)(handle >> 4);
                byChannel = (byte)(handle & 0xF);
            }
            else
            {
                devDevice = (TPCANDevice)(handle >> 8);
                byChannel = (byte)(handle & 0xFF);
            }

            // Constructs the PCAN-Basic Channel name and return it
            //
            if (isFD)
                return string.Format("{0}:FD {1} ({2:X2}h)", devDevice, byChannel, handle);
            else
                return string.Format("{0} {1} ({2:X2}h)", devDevice, byChannel, handle);
        }

        /// <summary>
        /// Help Function used to get an error as text
        /// </summary>
        /// <param name="error">Error code to be translated</param>
        /// <returns>A text with the translated error</returns>
        private string GetFormatedError(TPCANStatus error)
        {
            StringBuilder strTemp;

            // Creates a buffer big enough for a error-text
            //
            strTemp = new StringBuilder(256);
            // Gets the text using the GetErrorText API function
            // If the function success, the translated error is returned. If it fails,
            // a text describing the current error is returned.
            //
            if (PCANBasic.GetErrorText(error, 0, strTemp) != TPCANStatus.PCAN_ERROR_OK)
                return string.Format("An error occurred. Error-code's text (0x{0:X}) couldn't be retrieved", error);
            else
                return strTemp.ToString();
        }
        ToolStripMenuItem MnuStripItem;
        private void ActualGUIWarmup_Load(object sender, EventArgs e)
        {
            string[] row = new string[] { "File", "Edit", "View", "Refactor", "Project" };
            //MnuStrip.Dock = DockStyle.Top;
            foreach (string rw in row)
            {
                MnuStripItem = new ToolStripMenuItem(rw);
                menuStripTop.Items.Add(MnuStripItem);
                if (rw == "File")
                {
                    SubMenu(MnuStripItem, "File");
                }
            }
        }

        private void bindLeftTree()
        {
            //Left tree view
            treeView1.Nodes.Add("My Hardwares");
            treeView1.Nodes[0].Nodes.Add("Connected Hardware");
            treeView1.Nodes[0].Nodes.Add("Disabled Hardware");
            treeView1.Nodes.Add("Controllers");
            treeView1.Nodes[1].Nodes.Add("User Channels");
            treeView1.Nodes[1].Nodes.Add("System Channels");

        }

        private void bindLeftSubMeu(string menuSubItemText = "")
        {
            foreach (ToolStripMenuItem toolItem in menuStripLeft.Items)
            {
                //MessageBox.Show(toolItem.Text);
                if (toolItem.Text == "Hardware")
                {
                    toolItem.DropDownItems.Add(menuSubItemText);
                }
            }

        }

        public void SubMenu(ToolStripMenuItem MnuItems, string var)
        {
            if (var == "File")
            {
                string[] row = new string[] { "New", "Open", "Add", "Close", "Close Solution" };
                foreach (string rw in row)
                {
                    ToolStripMenuItem SSMenu = new ToolStripMenuItem(rw, null, ChildClick);
                    SubMenu(SSMenu, rw);
                    MnuItems.DropDownItems.Add(SSMenu);
                }
            }

            if (var == "New")
            {
                string[] row = new string[] { "Project", "Web Site", "File..", "Project From Existing Code" };
                foreach (string rw in row)
                {
                    ToolStripMenuItem SSSMenu = new ToolStripMenuItem(rw, null, ChildClick);
                    MnuItems.DropDownItems.Add(SSSMenu);
                }
            }
        }

        public void ChildClick(object sender, System.EventArgs e)
        {
            MessageBox.Show(string.Concat("You have Clicked '", sender.ToString(), "' Menu"), "Menu Items Event",
                                          MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void hardwareToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void menuStripLeft_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null && listBox1.SelectedItems.Count > 0)
            {
                listBox2.Items.Add(listBox1.SelectedItem);
                listBox1.Items.Remove(listBox1.SelectedItem);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox2.SelectedItem != null && listBox2.SelectedItems.Count > 0)
            {
                listBox1.Items.Add(listBox2.SelectedItem);
                listBox2.Items.Remove(listBox2.SelectedItem);
            }
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblSelectedChannels.Text = listBox2.SelectedItem.ToString();
        }

        private void InitRead_Click(object sender, EventArgs e)
        {
            TPCANStatus stsResult;

            // Connects a selected PCAN-Basic channel
            //
            if (m_IsFD)
                stsResult = PCANBasic.InitializeFD(
                    m_PcanHandle,
                    txtBitrate.Text);
            else
                stsResult = PCANBasic.Initialize(
                    m_PcanHandle,
                    m_Baudrate,
                    m_HwType,
                    Convert.ToUInt32(cbbIO.Text, 16),
                    Convert.ToUInt16(lblSelectedChannels.Text));

            if (stsResult != TPCANStatus.PCAN_ERROR_OK)
                if (stsResult != TPCANStatus.PCAN_ERROR_CAUTION)
                    MessageBox.Show(GetFormatedError(stsResult));
            //else
            //{
            //    IncludeTextMessage("******************************************************");
            //    IncludeTextMessage("The bitrate being used is different than the given one");
            //    IncludeTextMessage("******************************************************");
            //    stsResult = TPCANStatus.PCAN_ERROR_OK;
            //}
            //else
            // Prepares the PCAN-Basic's PCAN-Trace file
            //
            //ConfigureTraceFile();

            // Sets the connection status of the main-form
            //
            SetConnectionStatus(stsResult == TPCANStatus.PCAN_ERROR_OK);
        }

        /// <summary>
        /// Activates/deaactivates the different controls of the main-form according
        /// with the current connection status
        /// </summary>
        /// <param name="bConnected">Current status. True if connected, false otherwise</param>
        private void SetConnectionStatus(bool bConnected)
        {
            // Buttons
            //
            // btnIntialize.Enabled = !bConnected;
            /* btnRead.Enabled = bConnected && rdbManual.Checked;
             btnWrite.Enabled = bConnected;
             btnRelease.Enabled = bConnected;
             btnFilterApply.Enabled = bConnected;
             btnFilterQuery.Enabled = bConnected;
             btnGetVersions.Enabled = bConnected;
             btnHwRefresh.Enabled = !bConnected;
             btnStatus.Enabled = bConnected;
             btnReset.Enabled = bConnected; */


            cbbBaudrates.Enabled = !bConnected;
            cbbHwType.Enabled = !bConnected;
            cbbIO.Enabled = !bConnected;

            // Check-Buttons
            //
            chbCanFD.Enabled = !bConnected;

            // Hardware configuration and read mode
            //
            if (!bConnected)
                cbbChannel_SelectedIndexChanged(this, new EventArgs());
            else
                rdbTimer_CheckedChanged(this, new EventArgs());

            // Display messages in grid
            //
            tmrDisplay.Enabled = bConnected;
        }


        private void tmrRead_Tick(object sender, EventArgs e)
        {

        }

        private void tmrDisplay_Tick(object sender, EventArgs e)
        {

        }

        private void cbbChannel_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool bNonPnP;
            string strTemp;

            // Get the handle fromt he text being shown
            //
            // strTemp = cbbChannel.Text;
            //strTemp = strTemp.Substring(strTemp.IndexOf('(') + 1, 3);

            // strTemp = strTemp.Replace('h', ' ').Trim(' ');

            // Determines if the handle belong to a No Plug&Play hardware 
            //
            //m_PcanHandle = Convert.ToUInt16(strTemp, 16);
            bNonPnP = m_PcanHandle <= PCANBasic.PCAN_DNGBUS1;
            // Activates/deactivates configuration controls according with the 
            // kind of hardware
            //
            cbbHwType.Enabled = bNonPnP;
            cbbIO.Enabled = bNonPnP;
            //cbbInterrupt.Enabled = bNonPnP;
        }


        private void rdbTimer_CheckedChanged(object sender, EventArgs e)
        {
            if (!btnRelease.Enabled)
                return;

            // According with the kind of reading, a timer, a thread or a button will be enabled
            //
            if (rdbTimer.Checked)
            {
                // Abort Read Thread if it exists
                //
                if (m_ReadThread != null)
                {
                    m_ReadThread.Abort();
                    m_ReadThread.Join();
                    m_ReadThread = null;
                }

                // Enable Timer
                //
                tmrRead.Enabled = btnRelease.Enabled;
            }
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }
    }
}
