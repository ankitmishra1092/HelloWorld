﻿namespace WinFormsTestApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            btnhardwareName = new Button();
            btnHardwareConnected = new Button();
            button2 = new Button();
            btnActualAppRun = new Button();
            btnMainApp = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(295, 182);
            button1.Name = "button1";
            button1.Size = new Size(171, 23);
            button1.TabIndex = 0;
            button1.Text = "Start Message";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // btnhardwareName
            // 
            btnhardwareName.Location = new Point(532, 182);
            btnhardwareName.Name = "btnhardwareName";
            btnhardwareName.Size = new Size(150, 23);
            btnhardwareName.TabIndex = 1;
            btnhardwareName.Text = "Show Real code Practice";
            btnhardwareName.UseVisualStyleBackColor = true;
            btnhardwareName.Click += button2_Click;
            // 
            // btnHardwareConnected
            // 
            btnHardwareConnected.Location = new Point(45, 182);
            btnHardwareConnected.Name = "btnHardwareConnected";
            btnHardwareConnected.Size = new Size(187, 23);
            btnHardwareConnected.TabIndex = 2;
            btnHardwareConnected.Text = "Name Of hardware connected";
            btnHardwareConnected.UseVisualStyleBackColor = true;
            btnHardwareConnected.Click += btnHardwareConnected_Click;
            // 
            // button2
            // 
            button2.Location = new Point(295, 260);
            button2.Name = "button2";
            button2.Size = new Size(171, 23);
            button2.TabIndex = 3;
            button2.Text = "Read Data From USB";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click_1;
            // 
            // btnActualAppRun
            // 
            btnActualAppRun.Location = new Point(295, 318);
            btnActualAppRun.Name = "btnActualAppRun";
            btnActualAppRun.Size = new Size(171, 23);
            btnActualAppRun.TabIndex = 3;
            btnActualAppRun.Text = "Run Actual Application";
            btnActualAppRun.UseVisualStyleBackColor = true;
            btnActualAppRun.Click += btnActualRunApp_Click;
            // 
            // btnMainApp
            // 
            btnMainApp.Location = new Point(295, 368);
            btnMainApp.Name = "btnMainApp";
            btnMainApp.Size = new Size(171, 23);
            btnMainApp.TabIndex = 3;
            btnMainApp.Text = "Run Main Application";
            btnMainApp.UseVisualStyleBackColor = true;
            btnMainApp.Click += btnMainApp_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnMainApp);
            Controls.Add(btnActualAppRun);
            Controls.Add(button2);
            Controls.Add(btnHardwareConnected);
            Controls.Add(btnhardwareName);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button button1;
        private Button btnhardwareName;
        private Button btnHardwareConnected;
        private Button button2;
        private Button btnActualAppRun;
        private Button btnMainApp;
    }
}
