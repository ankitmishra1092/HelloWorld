using Peak.Can.Basic;
using Peak.Can.Basic.BackwardCompatibility;
using System;
using System.Text;
namespace WinFormsTestApp
{
    public partial class Form1 : Form
    {
        protected Worker myNewWorker;
        protected Broadcast broadcastNew;
        public Form1()
        {
            InitializeComponent();
            myNewWorker = new Worker();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            Worker myWorker = new Worker();
            PcanMessage message = new PcanMessage(0x100, MessageType.Standard, 3, new byte[] { 1, 2, 3 }, false);
            Broadcast broadcast = new Broadcast(message, 100);

            broadcastNew = new Broadcast(message, 100);

            myWorker.MessageAvailable += OnMessageAvailable;
            if (myWorker.AddBroadcast(ref broadcast))
            {
                Console.WriteLine($"Broadcast {broadcast.Index}' configured successfully.");
                MessageBox.Show($"Broadcast {broadcast.Index}' configured successfully.");
            }

            if (myNewWorker.AddBroadcast(ref broadcastNew))
            {
                MessageBox.Show("myNewWorker=" + broadcastNew.Message);
                MessageBox.Show($"Broadcast {broadcastNew.Index}' configured successfully.");

            }

            // myWorker.Start();
            myNewWorker.Start();
            Console.WriteLine("The Worker was activated successfully.");
            MessageBox.Show("The Worker was activated successfully.");



        }

        private void OnMessageAvailable(object? sender, MessageAvailableEventArgs e)
        {
            //MessageBox.Show("Message Availabe Args=" + e.ToString() + " Sender=" + sender);
            //MessageBox.Show("On message available method called.");
            //myNewWorker.Start();



        }

        private void button2_Click(object sender, EventArgs e)
        {
            //myNewWorker.PauseBroadcast(broadcastNew.Index);

            // Initialize the PCAN-Basic API
            TPCANStatus status = PCANBasic.Initialize(PCANBasic.PCAN_USBBUS1, TPCANBaudrate.PCAN_BAUD_500K);

            if (status == TPCANStatus.PCAN_ERROR_OK)
            {
                MessageBox.Show("PCAN-USB detected and initialized.");
                // Add further communication code here
            }
            else
            {
                MessageBox.Show("Failed to initialize PCAN-USB.");
            }

            // Uninitialize the PCAN-Basic API
            PCANBasic.Uninitialize(PCANBasic.PCAN_USBBUS1);

            Form2 form2 = new Form2();
            form2.Show();

            ushort[] channelsToCheck = { PCANBasic.PCAN_PCIBUS1, PCANBasic.PCAN_PCIBUS2, PCANBasic.PCAN_PCIBUS3, PCANBasic.PCAN_PCIBUS4 };
            uint condition;
            for (int i = 0; i < 4; i++)
            {
                //if (PCANBasic.GetValue(channelsToCheck[i], TPCANParameter.PCAN_CHANNEL_CONDITION, out condition, sizeof(uint)) == TPCANStatus.PCAN_ERROR_OK)
                   // if ((condition & PCANBasic.PCAN_CHANNEL_AVAILABLE) == PCANBasic.PCAN_CHANNEL_AVAILABLE)
                   //MessageBox.Show("The channel-handle 0x{0:X} is AVAILABLE =" + channelsToCheck[i]);
            }
        }

        private void btnHardwareConnected_Click(object sender, EventArgs e)
        {
            ushort[] channelsToCheck = { PCANBasic.PCAN_USBBUS1, PCANBasic.PCAN_USBBUS2, PCANBasic.PCAN_USBBUS3 };
            StringBuilder hardwareName = new StringBuilder(PCANBasic.MAX_LENGTH_HARDWARE_NAME);
            //TPCANChannelInformation[] info = new TPCANChannelInformation[3];
            var debugBus = PCANBasic.PCAN_NONEBUS;
            for (int i = 0; i < 3; i++)
            {
                if (PCANBasic.GetValue(channelsToCheck[i], TPCANParameter.PCAN_HARDWARE_NAME, hardwareName,
                PCANBasic.MAX_LENGTH_HARDWARE_NAME) == TPCANStatus.PCAN_ERROR_OK)
                {
                    if (hardwareName.ToString().Equals("PCAN-USB"))
                    {
                        debugBus = channelsToCheck[i];
                        break;
                    }
                }
            }
            if (debugBus != PCANBasic.PCAN_NONEBUS)
            {
                MessageBox.Show("Single PCAN-USB for debugging (0x{0:X}) found. Starting to work . . ." + debugBus);
                // Do work . . . 
            }
            else
                MessageBox.Show("Error! Single PCAN-USB Channel was not found. Terminating . . .");
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            TPCANStatus result;
            StringBuilder strMsg;
            TPCANMsg msg;

            // Initialize the PCAN-USB channel
            result = PCANBasic.Initialize(PCANBasic.PCAN_USBBUS1, TPCANBaudrate.PCAN_BAUD_500K);
            if (result != TPCANStatus.PCAN_ERROR_OK)
            {
                MessageBox.Show("Error initializing PCAN-USB: " + result);

                // Uninitialize the PCAN-USB channel
                result = PCANBasic.Uninitialize(PCANBasic.PCAN_USBBUS1);
                if (result != TPCANStatus.PCAN_ERROR_OK)
                {
                    MessageBox.Show("Error uninitializing PCAN-USB: " + result);
                }
                return;
            }

            // Read CAN messages
            while (true)
            {
                result = PCANBasic.Read(PCANBasic.PCAN_USBBUS1, out msg);
                if (result == TPCANStatus.PCAN_ERROR_OK)
                {
                    MessageBox.Show("ID: " + msg.ID + ", Data: " + BitConverter.ToString(msg.DATA));
                }
                else if (result != TPCANStatus.PCAN_ERROR_QRCVEMPTY)
                {
                    MessageBox.Show("Error reading CAN message: " + result);
                }
            }


        }

        private void btnActualRunApp_Click(object sender, EventArgs e)
        {
            ActualGUIWarmup actualApp = new ActualGUIWarmup();

            actualApp.Show();
        }


        private void btnMainApp_Click(object sender, EventArgs e)
        {
            MainForm mainApp = new MainForm();

            mainApp.Show();
        }

    }
}
