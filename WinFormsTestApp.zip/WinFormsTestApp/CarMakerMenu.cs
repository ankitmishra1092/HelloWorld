﻿using Peak.Can.Basic.BackwardCompatibility;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
/// <summary>
/// Inclusion of PEAK PCAN-Basic namespace
/// </summary>
using Peak.Can.Basic;
using TPCANHandle = System.UInt16;
using TPCANBitrateFD = System.String;
using TPCANTimestampFD = System.UInt64;
using Peak.Can.Basic.BackwardCompatibility;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Security.Authentication.ExtendedProtection;
using System.Net;


namespace WinFormsTestApp
{
    public partial class CarMakerMenu : Form
    {
        public CarMakerMenu()
        {
            InitializeComponent();
            getDBData();
            bindLeftTree();
            fillAvailableChannels();
            for (int i = 0; i < treeView1.Nodes[0].Nodes[0].Nodes.Count; i++)
            {
                treeView1.Nodes[0].Nodes[0].Nodes[i].StateImageIndex = 0;
            }
            treeView1.NodeMouseClick += TreeView1_NodeMouseClick;
        }

        ToolStripMenuItem MnuStripItem;
        private TPCANHandle m_PcanHandle;
        public static string cbbChannelText = "";
        public static List<string> selectedChannelList;
        private ImageList _stateImageList;
        DataSet dataSet;
        private void CarMakerMenu_Load(object sender, EventArgs e)
        {

            selectedChannelList = new List<string>();
            string[] row = new string[] { "File", "Edit", "View", "Refactor", "Project" };
            foreach (string rw in row)
            {
                MnuStripItem = new ToolStripMenuItem(rw);
                menuStripTop.Items.Add(MnuStripItem);
                if (rw == "File")
                {
                    SubMenu(MnuStripItem, "File");
                }
            }

            // Subscribe to the DrawItem and MouseClick events
            tabControl1.DrawItem += new DrawItemEventHandler(tabControl1_DrawItem);
            tabControl1.MouseClick += new MouseEventHandler(tabControl1_MouseClick);
            tabControl1.DrawMode = TabDrawMode.OwnerDrawFixed;
            // Set the SizeMode to Fixed and specify the ItemSize 
            tabControl1.SizeMode = TabSizeMode.Fixed;
            tabControl1.ItemSize = new Size(180, 30); // Set the width to 200 and height to 30

        }

        private void getDBData()
        {
            var conStr = System.Configuration.ConfigurationManager.ConnectionStrings["CarMakerDBConnectionString"].ConnectionString;
            string query = "fetchMenusSubMenus";
            using (SqlConnection connection = new SqlConnection())
            {
                // Bypass SSL certificate validation
                ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
                connection.ConnectionString = conStr;
                connection.Open();
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.CommandType = CommandType.StoredProcedure;
                using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                {
                    //DataTable dataTable = new DataTable(); 
                    dataSet = new DataSet();
                    adapter.Fill(dataSet);
                }
                connection.Close();
            }


        }
        private Bitmap CreateCheckBoxBitmap(bool isChecked)
        {
            Bitmap bmp = new Bitmap(16, 16);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                ControlPaint.DrawCheckBox(g, new Rectangle(0, 0, 16, 16), isChecked ? ButtonState.Checked : ButtonState.Normal);
            }
            return bmp;
        }
        private void bindLeftTree()
        {
            treeView1.CheckBoxes = false;
            _stateImageList = new ImageList();
            _stateImageList.Images.Add("unchecked", CreateCheckBoxBitmap(false));
            _stateImageList.Images.Add("checked", CreateCheckBoxBitmap(true));
            treeView1.StateImageList = _stateImageList;
            //Left tree view
            // Read and display the data
            foreach (DataTable table in dataSet.Tables)
            {
                foreach (DataRow row in table.Rows)
                {
                    foreach (DataColumn column in table.Columns)
                    {
                        string columnName = column.ColumnName;
                        object columnValue = row[column];
                        //MessageBox.Show($"{columnName}: {columnValue}");
                        //columnName == "menu_name" && columnValue != null &&
                        if (columnValue.ToString() == "My Hardware")
                        {
                            treeView1.Nodes.Add(columnValue.ToString());
                        }
                        if (columnValue.ToString() == "Controllers")
                        {
                            treeView1.Nodes.Add(columnValue.ToString());
                        }
                        if (columnValue.ToString() == "Connected Hardware")
                        {
                            treeView1.Nodes[0].Nodes.Add(columnValue.ToString());
                        }
                        if (columnValue.ToString() == "Disabled Hardware")
                        {
                            treeView1.Nodes[0].Nodes.Add(columnValue.ToString());
                        }
                    }
                }
            }

            
           
            treeView1.Nodes.Add("Controllers");
            treeView1.Nodes[1].Nodes.Add("User Channels");
            treeView1.Nodes[1].Nodes.Add("System Channels");
            treeView1.Nodes[0].Nodes[0].StateImageIndex = 1;
            treeView1.Nodes[0].Nodes[1].StateImageIndex = 0;
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
        }

        private void TreeView1_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        { // You can get the clicked node using e.Node
            TreeNode clickedNode = e.Node;
            string selectedNodeText = e.Node.Text;
            Form2 frmObj = new Form2();
            if (treeView1.Nodes[0].Nodes[0].Nodes.Count > 0)
            {
                if (selectedNodeText == treeView1.Nodes[0].Nodes[0].Nodes[e.Node.Index].Text)
                {
                    cbbChannelText = selectedNodeText;
                    if (!selectedChannelList.Contains(cbbChannelText))
                    {
                        selectedChannelList.Add(cbbChannelText);
                        AddNewTab(frmObj, cbbChannelText);
                    }
                    if (tabControl1.TabPages[GetTabIndexByTabText(tabControl1, cbbChannelText)].Text == cbbChannelText)
                    {
                        tabControl1.SelectedTab = tabControl1.TabPages[GetTabIndexByTabText(tabControl1, cbbChannelText)];
                    }
                    if (treeView1.Nodes[0].Nodes[0].Nodes[e.Node.Index].StateImageIndex == 0)
                    {
                        treeView1.Nodes[0].Nodes[0].Nodes[e.Node.Index].StateImageIndex = 1;
                        DisableTabPage(tabControl1.TabPages[GetTabIndexByTabText(tabControl1, cbbChannelText)], false);
                    }
                    else
                    {
                        treeView1.Nodes[0].Nodes[0].Nodes[e.Node.Index].StateImageIndex = 0;
                        DisableTabPage(tabControl1.TabPages[GetTabIndexByTabText(tabControl1, cbbChannelText)], true);
                    }

                }
            }

        }

        private void DisableTabPage(TabPage tabPage, bool disable)
        {
            for (int i = 0; i < tabPage.Controls.Count; i++)
            {
                tabPage.Controls[i].Enabled = !disable;
            }

        }

        private int GetTabIndexByTabText(TabControl tabControl, string tabText)
        {
            for (int i = 0; i < tabControl.TabPages.Count; i++)
            {
                if (tabControl.TabPages[i].Text == tabText)
                {
                    return i;
                }
            }
            return -1; // Return -1 if no match is found
        }
        public void SubMenu(ToolStripMenuItem MnuItems, string var)
        {
            if (var == "File")
            {
                string[] row = new string[] { "New", "Open", "Add", "Close", "Close Solution" };
                foreach (string rw in row)
                {
                    ToolStripMenuItem SSMenu = new ToolStripMenuItem(rw, null, ChildClick);
                    SubMenu(SSMenu, rw);
                    MnuItems.DropDownItems.Add(SSMenu);
                }
            }

            if (var == "New")
            {
                string[] row = new string[] { "Project", "Web Site", "File..", "Project From Existing Code" };
                foreach (string rw in row)
                {
                    ToolStripMenuItem SSSMenu = new ToolStripMenuItem(rw, null, ChildClick);
                    MnuItems.DropDownItems.Add(SSSMenu);
                }
            }
        }

        public void ChildClick(object sender, System.EventArgs e)
        {
            MessageBox.Show(string.Concat("You have Clicked '", sender.ToString(), "' Menu"), "Menu Items Event",
                                          MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void AddNewTab(Form frm, string tabName)
        {

            TabPage tab = new TabPage(tabName);

            frm.TopLevel = false;

            frm.Parent = tab;

            frm.Visible = true;

            tabControl1.TabPages.Add(tab);

            frm.Dock = DockStyle.Fill;
            //frm.Location = new Point((tab.Width - frm.Width) / 2, (tab.Height - frm.Height) / 2);

            tabControl1.SelectedTab = tab;

        }


        private void tabControl1_DrawItem(object sender, DrawItemEventArgs e)
        {
            // Draw the tab text
            e.Graphics.DrawString(tabControl1.TabPages[e.Index].Text, tabControl1.Font, Brushes.Black, e.Bounds.Left + 10, e.Bounds.Top + 4);

            // Draw the close button
            Rectangle closeRect = new Rectangle(e.Bounds.Right - 15, e.Bounds.Top + 4, 15, 20);
            e.Graphics.DrawRectangle(Pens.Red, closeRect);
            e.Graphics.DrawLine(Pens.Red, closeRect.Left, closeRect.Top, closeRect.Right, closeRect.Bottom);
            e.Graphics.DrawLine(Pens.Red, closeRect.Right, closeRect.Top, closeRect.Left, closeRect.Bottom);
        }

        private void tabControl1_MouseClick(object sender, MouseEventArgs e)
        {
            for (int i = 0; i < tabControl1.TabPages.Count; i++)
            {
                Rectangle r = tabControl1.GetTabRect(i);
                Rectangle closeRect = new Rectangle(r.Right - 15, r.Top + 4, 10, 10);

                if (closeRect.Contains(e.Location))
                {
                    tabControl1.TabPages.RemoveAt(i);
                    //selectedChannelList.RemoveAt(i);
                    break;
                }
            }
        }


        private void fillAvailableChannels()
        {
            TPCANStatus stsResult;
            uint iChannelsCount;
            bool bIsFD;

            // Clears the Channel comboBox and fill it again with 
            // the PCAN-Basic handles for no-Plug&Play hardware and
            // the detected Plug&Play hardware
            //

            try
            {

                // Checks for available Plug&Play channels
                //
                stsResult = PCANBasic.GetValue(PCANBasic.PCAN_NONEBUS, TPCANParameter.PCAN_ATTACHED_CHANNELS_COUNT, out iChannelsCount, sizeof(uint));
                if (stsResult == TPCANStatus.PCAN_ERROR_OK)
                {

                    TPCANChannelInformation[] info = new TPCANChannelInformation[iChannelsCount];

                    stsResult = PCANBasic.GetValue(PCANBasic.PCAN_NONEBUS, TPCANParameter.PCAN_ATTACHED_CHANNELS, info);
                    if (stsResult == TPCANStatus.PCAN_ERROR_OK)
                        // Include only connectable channels
                        //
                        foreach (TPCANChannelInformation channel in info)
                            if ((channel.channel_condition & PCANBasic.PCAN_CHANNEL_AVAILABLE) == PCANBasic.PCAN_CHANNEL_AVAILABLE)
                            {
                                bIsFD = (channel.device_features & PCANBasic.FEATURE_FD_CAPABLE) == PCANBasic.FEATURE_FD_CAPABLE;
                                treeView1.Nodes[0].Nodes[0].Nodes.Add(FormatChannelName(channel.channel_handle, bIsFD));
                            }
                }


                if (stsResult != TPCANStatus.PCAN_ERROR_OK)
                    MessageBox.Show(GetFormatedError(stsResult));
            }
            catch (DllNotFoundException)
            {
                MessageBox.Show("Unable to find the library: PCANBasic.dll !", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(-1);
            }
        }

        /// <summary>
        /// Gets the formated text for a PCAN-Basic channel handle
        /// </summary>
        /// <param name="handle">PCAN-Basic Handle to format</param>
        /// <param name="isFD">If the channel is FD capable</param>
        /// <returns>The formatted text for a channel</returns>
        private string FormatChannelName(TPCANHandle handle, bool isFD)
        {
            TPCANDevice devDevice;
            byte byChannel;

            // Gets the owner device and channel for a 
            // PCAN-Basic handle
            //
            if (handle < 0x100)
            {
                devDevice = (TPCANDevice)(handle >> 4);
                byChannel = (byte)(handle & 0xF);
            }
            else
            {
                devDevice = (TPCANDevice)(handle >> 8);
                byChannel = (byte)(handle & 0xFF);
            }

            // Constructs the PCAN-Basic Channel name and return it
            //
            if (isFD)
                return string.Format("{0}:FD {1} ({2:X2}h)", devDevice, byChannel, handle);
            else
                return string.Format("{0} {1} ({2:X2}h)", devDevice, byChannel, handle);
        }

        /// <summary>
        /// Help Function used to get an error as text
        /// </summary>
        /// <param name="error">Error code to be translated</param>
        /// <returns>A text with the translated error</returns>
        private string GetFormatedError(TPCANStatus error)
        {
            StringBuilder strTemp;

            // Creates a buffer big enough for a error-text
            //
            strTemp = new StringBuilder(256);
            // Gets the text using the GetErrorText API function
            // If the function success, the translated error is returned. If it fails,
            // a text describing the current error is returned.
            //
            if (PCANBasic.GetErrorText(error, 0, strTemp) != TPCANStatus.PCAN_ERROR_OK)
                return string.Format("An error occurred. Error-code's text (0x{0:X}) couldn't be retrieved", error);
            else
                return strTemp.ToString();
        }


    }
}
