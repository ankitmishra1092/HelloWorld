﻿namespace WinFormsTestApp
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            sidebar = new FlowLayoutPanel();
            button1 = new Button();
            MenuContainerFlPanel = new FlowLayoutPanel();
            Hardware = new Button();
            button3 = new Button();
            button4 = new Button();
            MenuTransitionTmr = new System.Windows.Forms.Timer(components);
            SidebartransitionTmr = new System.Windows.Forms.Timer(components);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            sidebar.SuspendLayout();
            MenuContainerFlPanel.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(12, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(65, 55);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // panel1
            // 
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1437, 70);
            panel1.TabIndex = 1;
            // 
            // sidebar
            // 
            sidebar.BackColor = SystemColors.ActiveCaptionText;
            sidebar.Controls.Add(button1);
            sidebar.Controls.Add(MenuContainerFlPanel);
            sidebar.Dock = DockStyle.Left;
            sidebar.Location = new Point(0, 70);
            sidebar.Name = "sidebar";
            sidebar.Size = new Size(267, 624);
            sidebar.TabIndex = 2;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ActiveCaptionText;
            button1.ForeColor = SystemColors.Control;
            button1.Location = new Point(3, 3);
            button1.Name = "button1";
            button1.Size = new Size(256, 71);
            button1.TabIndex = 3;
            button1.Text = "Dashboard";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // MenuContainerFlPanel
            // 
            MenuContainerFlPanel.BackColor = SystemColors.ActiveCaptionText;
            MenuContainerFlPanel.Controls.Add(Hardware);
            MenuContainerFlPanel.Controls.Add(button3);
            MenuContainerFlPanel.Controls.Add(button4);
            MenuContainerFlPanel.Location = new Point(3, 80);
            MenuContainerFlPanel.Name = "MenuContainerFlPanel";
            MenuContainerFlPanel.Size = new Size(266, 71);
            MenuContainerFlPanel.TabIndex = 4;
            // 
            // Hardware
            // 
            Hardware.BackColor = SystemColors.ActiveCaptionText;
            Hardware.ForeColor = SystemColors.Control;
            Hardware.Location = new Point(3, 3);
            Hardware.Name = "Hardware";
            Hardware.Padding = new Padding(5, 0, 0, 0);
            Hardware.Size = new Size(256, 71);
            Hardware.TabIndex = 3;
            Hardware.Text = "Hardware";
            Hardware.TextAlign = ContentAlignment.MiddleLeft;
            Hardware.UseVisualStyleBackColor = false;
            Hardware.Click += button1_Click;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.ActiveCaptionText;
            button3.ForeColor = SystemColors.Control;
            button3.Location = new Point(3, 80);
            button3.Name = "button3";
            button3.Padding = new Padding(5, 0, 0, 0);
            button3.Size = new Size(256, 71);
            button3.TabIndex = 3;
            button3.Text = "CAN";
            button3.TextAlign = ContentAlignment.MiddleLeft;
            button3.UseVisualStyleBackColor = false;
            button3.Click += button1_Click;
            // 
            // button4
            // 
            button4.BackColor = SystemColors.ActiveCaptionText;
            button4.ForeColor = SystemColors.Control;
            button4.Location = new Point(3, 157);
            button4.Name = "button4";
            button4.Padding = new Padding(5, 0, 0, 0);
            button4.Size = new Size(256, 71);
            button4.TabIndex = 3;
            button4.Text = "CAN FD";
            button4.TextAlign = ContentAlignment.MiddleLeft;
            button4.UseVisualStyleBackColor = false;
            button4.Click += button1_Click;
            // 
            // MenuTransitionTmr
            // 
            MenuTransitionTmr.Tick += MenuTransitionTmr_Tick;
            // 
            // SidebartransitionTmr
            // 
            SidebartransitionTmr.Interval = 10;
            SidebartransitionTmr.Tick += SidebartransitionTmr_Tick;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1437, 694);
            Controls.Add(sidebar);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "MainForm";
            Text = "MainForm";
            Load += MainForm_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            sidebar.ResumeLayout(false);
            MenuContainerFlPanel.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private Panel panel1;
        private FlowLayoutPanel sidebar;
        private Button button1;
        private Button Hardware;
        private Button button3;
        private FlowLayoutPanel MenuContainerFlPanel;
        private Button button4;
        private System.Windows.Forms.Timer MenuTransitionTmr;
        private System.Windows.Forms.Timer SidebartransitionTmr;
    }
}