﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsTestApp
{
    public class ClosableTabControl : TabControl 
    {
        protected override void OnDrawItem(DrawItemEventArgs e)
        {
            base.OnDrawItem(e);

            // Draw the tab text
            e.Graphics.DrawString(this.TabPages[e.Index].Text, this.Font, Brushes.Black, e.Bounds.Left + 10, e.Bounds.Top + 4);

            // Draw the close button
            Rectangle closeRect = new Rectangle(e.Bounds.Right - 15, e.Bounds.Top + 4, 10, 10);
            e.Graphics.DrawRectangle(Pens.Black, closeRect);
            e.Graphics.DrawLine(Pens.Black, closeRect.Left, closeRect.Top, closeRect.Right, closeRect.Bottom);
            e.Graphics.DrawLine(Pens.Black, closeRect.Right, closeRect.Top, closeRect.Left, closeRect.Bottom);
        }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            base.OnMouseClick(e);

            for (int i = 0; i < this.TabPages.Count; i++)
            {
                Rectangle r = GetTabRect(i);
                Rectangle closeRect = new Rectangle(r.Right - 15, r.Top + 4, 10, 10);

                if (closeRect.Contains(e.Location))
                {
                    this.TabPages.RemoveAt(i);
                    break;
                }
            }
        }
    }
}
