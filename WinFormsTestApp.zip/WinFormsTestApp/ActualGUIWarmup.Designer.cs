﻿namespace WinFormsTestApp
{
    partial class ActualGUIWarmup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            listBox1 = new ListBox();
            label1 = new Label();
            label2 = new Label();
            listBox2 = new ListBox();
            button1 = new Button();
            button2 = new Button();
            InitRead = new Button();
            lblSelectedChannels = new Label();
            label3 = new Label();
            listView1 = new ListView();
            cbbBaudrates = new ComboBox();
            lblBaudrate = new Label();
            cbbHwType = new ComboBox();
            lblHardwaretype = new Label();
            chbCanFD = new CheckBox();
            cbbIO = new ComboBox();
            lblIOPort = new Label();
            rdbTimer = new RadioButton();
            chbShowPeriod = new CheckBox();
            tmrRead = new System.Windows.Forms.Timer(components);
            tmrDisplay = new System.Windows.Forms.Timer(components);
            txtBitrate = new TextBox();
            label4 = new Label();
            btnRelease = new Button();
            panel1 = new Panel();
            menuStripLeft = new MenuStrip();
            hardwareToolStripMenuItem = new ToolStripMenuItem();
            userChannelsToolStripMenuItem = new ToolStripMenuItem();
            systemChannelsToolStripMenuItem = new ToolStripMenuItem();
            panel2 = new Panel();
            menuStripTop = new MenuStrip();
            systemToolStripMenuItem = new ToolStripMenuItem();
            treeView1 = new TreeView();
            panel3 = new Panel();
            panel1.SuspendLayout();
            menuStripLeft.SuspendLayout();
            panel2.SuspendLayout();
            menuStripTop.SuspendLayout();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(257, 99);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(120, 244);
            listBox1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(257, 53);
            label1.Name = "label1";
            label1.Size = new Size(107, 15);
            label1.TabIndex = 1;
            label1.Text = "Available Channels";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(483, 65);
            label2.Name = "label2";
            label2.Size = new Size(135, 15);
            label2.TabIndex = 1;
            label2.Text = "Choose Active Channels";
            // 
            // listBox2
            // 
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 15;
            listBox2.Location = new Point(498, 99);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(120, 244);
            listBox2.TabIndex = 0;
            listBox2.SelectedIndexChanged += listBox2_SelectedIndexChanged;
            // 
            // button1
            // 
            button1.Location = new Point(383, 132);
            button1.Name = "button1";
            button1.Size = new Size(75, 52);
            button1.TabIndex = 2;
            button1.Text = "Add Channel";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(383, 227);
            button2.Name = "button2";
            button2.Size = new Size(75, 52);
            button2.TabIndex = 2;
            button2.Text = "Remove Channel";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // InitRead
            // 
            InitRead.Location = new Point(1118, 53);
            InitRead.Name = "InitRead";
            InitRead.Size = new Size(156, 23);
            InitRead.TabIndex = 3;
            InitRead.Text = "Initialize and Read";
            InitRead.UseVisualStyleBackColor = true;
            InitRead.Click += InitRead_Click;
            // 
            // lblSelectedChannels
            // 
            lblSelectedChannels.AutoSize = true;
            lblSelectedChannels.Location = new Point(711, 99);
            lblSelectedChannels.Name = "lblSelectedChannels";
            lblSelectedChannels.Size = new Size(98, 15);
            lblSelectedChannels.TabIndex = 4;
            lblSelectedChannels.Text = "Selected Channel";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(711, 65);
            label3.Name = "label3";
            label3.Size = new Size(98, 15);
            label3.TabIndex = 4;
            label3.Text = "Selected Channel";
            // 
            // listView1
            // 
            listView1.Location = new Point(1094, 130);
            listView1.Name = "listView1";
            listView1.Size = new Size(343, 97);
            listView1.TabIndex = 5;
            listView1.UseCompatibleStateImageBehavior = false;
            // 
            // cbbBaudrates
            // 
            cbbBaudrates.FormattingEnabled = true;
            cbbBaudrates.Items.AddRange(new object[] { "1 MBit/sec", "800 kBit/s", "500 kBit/sec", "250 kBit/sec", "125 kBit/sec", "100 kBit/sec", "95,238 kBit/s", "83,333 kBit/s", "50 kBit/sec", "47,619 kBit/s", "33,333 kBit/s", "20 kBit/sec", "10 kBit/sec", "5 kBit/sec" });
            cbbBaudrates.Location = new Point(884, 91);
            cbbBaudrates.Name = "cbbBaudrates";
            cbbBaudrates.Size = new Size(121, 23);
            cbbBaudrates.TabIndex = 6;
            // 
            // lblBaudrate
            // 
            lblBaudrate.AutoSize = true;
            lblBaudrate.Location = new Point(896, 61);
            lblBaudrate.Name = "lblBaudrate";
            lblBaudrate.Size = new Size(97, 15);
            lblBaudrate.TabIndex = 7;
            lblBaudrate.Text = "Choose Baudrate";
            // 
            // cbbHwType
            // 
            cbbHwType.FormattingEnabled = true;
            cbbHwType.Items.AddRange(new object[] { "ISA-82C200", "ISA-SJA1000", "ISA-PHYTEC", "DNG-82C200", "DNG-82C200 EPP", "DNG-SJA1000", "DNG-SJA1000 EPP" });
            cbbHwType.Location = new Point(711, 148);
            cbbHwType.Name = "cbbHwType";
            cbbHwType.Size = new Size(121, 23);
            cbbHwType.TabIndex = 8;
            // 
            // lblHardwaretype
            // 
            lblHardwaretype.AutoSize = true;
            lblHardwaretype.Location = new Point(711, 130);
            lblHardwaretype.Name = "lblHardwaretype";
            lblHardwaretype.Size = new Size(81, 15);
            lblHardwaretype.TabIndex = 9;
            lblHardwaretype.Text = "Hardwaretype";
            // 
            // chbCanFD
            // 
            chbCanFD.AutoSize = true;
            chbCanFD.Location = new Point(711, 193);
            chbCanFD.Name = "chbCanFD";
            chbCanFD.Size = new Size(70, 19);
            chbCanFD.TabIndex = 15;
            chbCanFD.Text = "CAN-FD";
            chbCanFD.UseVisualStyleBackColor = true;
            // 
            // cbbIO
            // 
            cbbIO.FormattingEnabled = true;
            cbbIO.Items.AddRange(new object[] { "0100", "0120", "0140", "0200", "0220", "0240", "0260", "0278", "0280", "02A0", "02C0", "02E0", "02E8", "02F8", "0300", "0320", "0340", "0360", "0378", "0380", "03BC", "03E0", "03E8", "03F8" });
            cbbIO.Location = new Point(884, 148);
            cbbIO.Name = "cbbIO";
            cbbIO.Size = new Size(121, 23);
            cbbIO.TabIndex = 16;
            // 
            // lblIOPort
            // 
            lblIOPort.AutoSize = true;
            lblIOPort.Location = new Point(884, 130);
            lblIOPort.Name = "lblIOPort";
            lblIOPort.Size = new Size(49, 15);
            lblIOPort.TabIndex = 17;
            lblIOPort.Text = "I/O Port";
            // 
            // rdbTimer
            // 
            rdbTimer.AutoSize = true;
            rdbTimer.Checked = true;
            rdbTimer.Location = new Point(711, 218);
            rdbTimer.Name = "rdbTimer";
            rdbTimer.Size = new Size(125, 19);
            rdbTimer.TabIndex = 18;
            rdbTimer.TabStop = true;
            rdbTimer.Text = "Read using a Timer";
            rdbTimer.UseVisualStyleBackColor = true;
            rdbTimer.CheckedChanged += rdbTimer_CheckedChanged;
            // 
            // chbShowPeriod
            // 
            chbShowPeriod.AutoSize = true;
            chbShowPeriod.Checked = true;
            chbShowPeriod.CheckState = CheckState.Checked;
            chbShowPeriod.Location = new Point(711, 260);
            chbShowPeriod.Name = "chbShowPeriod";
            chbShowPeriod.Size = new Size(136, 19);
            chbShowPeriod.TabIndex = 19;
            chbShowPeriod.Text = "Timestamp as period";
            chbShowPeriod.UseVisualStyleBackColor = true;
            // 
            // tmrRead
            // 
            tmrRead.Interval = 50;
            tmrRead.Tick += tmrRead_Tick;
            // 
            // tmrDisplay
            // 
            tmrDisplay.Tick += tmrDisplay_Tick;
            // 
            // txtBitrate
            // 
            txtBitrate.Location = new Point(711, 346);
            txtBitrate.Multiline = true;
            txtBitrate.Name = "txtBitrate";
            txtBitrate.Size = new Size(297, 72);
            txtBitrate.TabIndex = 20;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(711, 328);
            label4.Name = "label4";
            label4.Size = new Size(91, 15);
            label4.TabIndex = 21;
            label4.Text = "Is CAN FD Input";
            // 
            // btnRelease
            // 
            btnRelease.Location = new Point(1331, 53);
            btnRelease.Name = "btnRelease";
            btnRelease.Size = new Size(96, 23);
            btnRelease.TabIndex = 22;
            btnRelease.Text = "Release";
            btnRelease.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveCaption;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(menuStripLeft);
            panel1.Location = new Point(3, 38);
            panel1.Name = "panel1";
            panel1.Size = new Size(224, 100);
            panel1.TabIndex = 23;
            panel1.Visible = false;
            // 
            // menuStripLeft
            // 
            menuStripLeft.BackColor = SystemColors.ControlLight;
            menuStripLeft.Dock = DockStyle.Left;
            menuStripLeft.Items.AddRange(new ToolStripItem[] { hardwareToolStripMenuItem, userChannelsToolStripMenuItem, systemChannelsToolStripMenuItem });
            menuStripLeft.Location = new Point(0, 0);
            menuStripLeft.Name = "menuStripLeft";
            menuStripLeft.Size = new Size(115, 98);
            menuStripLeft.TabIndex = 24;
            menuStripLeft.Text = "menuStrip1";
            menuStripLeft.ItemClicked += menuStripLeft_ItemClicked;
            // 
            // hardwareToolStripMenuItem
            // 
            hardwareToolStripMenuItem.Margin = new Padding(0, 0, 0, 2);
            hardwareToolStripMenuItem.Name = "hardwareToolStripMenuItem";
            hardwareToolStripMenuItem.Padding = new Padding(4, 0, 4, 1);
            hardwareToolStripMenuItem.Size = new Size(102, 20);
            hardwareToolStripMenuItem.Text = "Hardware";
            hardwareToolStripMenuItem.TextAlign = ContentAlignment.MiddleLeft;
            hardwareToolStripMenuItem.Click += hardwareToolStripMenuItem_Click;
            // 
            // userChannelsToolStripMenuItem
            // 
            userChannelsToolStripMenuItem.Margin = new Padding(0, 0, 0, 2);
            userChannelsToolStripMenuItem.Name = "userChannelsToolStripMenuItem";
            userChannelsToolStripMenuItem.Padding = new Padding(4, 0, 4, 1);
            userChannelsToolStripMenuItem.Size = new Size(102, 20);
            userChannelsToolStripMenuItem.Text = "User Channels";
            userChannelsToolStripMenuItem.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // systemChannelsToolStripMenuItem
            // 
            systemChannelsToolStripMenuItem.Margin = new Padding(0, 0, 0, 2);
            systemChannelsToolStripMenuItem.Name = "systemChannelsToolStripMenuItem";
            systemChannelsToolStripMenuItem.Padding = new Padding(4, 0, 4, 1);
            systemChannelsToolStripMenuItem.Size = new Size(102, 20);
            systemChannelsToolStripMenuItem.Text = "System Channels";
            systemChannelsToolStripMenuItem.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.ActiveCaption;
            panel2.Controls.Add(menuStripTop);
            panel2.Location = new Point(-7, -4);
            panel2.Name = "panel2";
            panel2.Size = new Size(1487, 36);
            panel2.TabIndex = 25;
            // 
            // menuStripTop
            // 
            menuStripTop.Items.AddRange(new ToolStripItem[] { systemToolStripMenuItem });
            menuStripTop.Location = new Point(0, 0);
            menuStripTop.Name = "menuStripTop";
            menuStripTop.Size = new Size(1487, 24);
            menuStripTop.TabIndex = 25;
            menuStripTop.Text = "menuStrip1";
            // 
            // systemToolStripMenuItem
            // 
            systemToolStripMenuItem.Margin = new Padding(0, 0, 10, 0);
            systemToolStripMenuItem.Name = "systemToolStripMenuItem";
            systemToolStripMenuItem.Size = new Size(73, 20);
            systemToolStripMenuItem.Text = "Car Maker";
            // 
            // treeView1
            // 
            treeView1.CheckBoxes = true;
            treeView1.Dock = DockStyle.Left;
            treeView1.Location = new Point(0, 0);
            treeView1.Name = "treeView1";
            treeView1.Size = new Size(211, 627);
            treeView1.TabIndex = 26;
            treeView1.AfterSelect += treeView1_AfterSelect;
            // 
            // panel3
            // 
            panel3.BackColor = SystemColors.ControlLight;
            panel3.Controls.Add(treeView1);
            panel3.Location = new Point(2, 38);
            panel3.Name = "panel3";
            panel3.Size = new Size(225, 627);
            panel3.TabIndex = 27;
            // 
            // ActualGUIWarmup
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1470, 656);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(btnRelease);
            Controls.Add(label4);
            Controls.Add(txtBitrate);
            Controls.Add(chbShowPeriod);
            Controls.Add(rdbTimer);
            Controls.Add(lblIOPort);
            Controls.Add(cbbIO);
            Controls.Add(chbCanFD);
            Controls.Add(lblHardwaretype);
            Controls.Add(cbbHwType);
            Controls.Add(lblBaudrate);
            Controls.Add(cbbBaudrates);
            Controls.Add(listView1);
            Controls.Add(label3);
            Controls.Add(lblSelectedChannels);
            Controls.Add(InitRead);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(listBox2);
            Controls.Add(listBox1);
            Name = "ActualGUIWarmup";
            Text = "ActualGUIWarmup";
            Load += ActualGUIWarmup_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            menuStripLeft.ResumeLayout(false);
            menuStripLeft.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            menuStripTop.ResumeLayout(false);
            menuStripTop.PerformLayout();
            panel3.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox listBox1;
        private Label label1;
        private Label label2;
        private ListBox listBox2;
        private Button button1;
        private Button button2;
        private Button InitRead;
        private Label lblSelectedChannels;
        private Label label3;
        private ListView listView1;
        private ComboBox cbbBaudrates;
        private Label lblBaudrate;
        private ComboBox cbbHwType;
        private Label lblHardwaretype;
        private CheckBox chbCanFD;
        private ComboBox cbbIO;
        private Label lblIOPort;
        private RadioButton rdbTimer;
        private CheckBox chbShowPeriod;
        private System.Windows.Forms.Timer tmrRead;
        private System.Windows.Forms.Timer tmrDisplay;
        private TextBox txtBitrate;
        private Label label4;
        private Button btnRelease;
        private Panel panel1;
        private MenuStrip menuStripLeft;
        private ToolStripMenuItem hardwareToolStripMenuItem;
        private ToolStripMenuItem userChannelsToolStripMenuItem;
        private ToolStripMenuItem systemChannelsToolStripMenuItem;
        private Panel panel2;
        private MenuStrip menuStripTop;
        private ToolStripMenuItem systemToolStripMenuItem;
        private TreeView treeView1;
        private Panel panel3;
    }
}