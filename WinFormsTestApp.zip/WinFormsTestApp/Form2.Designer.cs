﻿namespace WinFormsTestApp
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            groupBox1 = new GroupBox();
            label2 = new Label();
            chbShowPeriod = new CheckBox();
            rdbManual = new RadioButton();
            rdbEvent = new RadioButton();
            rdbTimer = new RadioButton();
            chbCanFD = new CheckBox();
            txtBitrate = new TextBox();
            btnRelease = new Button();
            btnIntialize = new Button();
            lblInterrupt = new Label();
            cbbInterrupt = new ComboBox();
            lblIOPort = new Label();
            cbbIO = new ComboBox();
            lblHardwaretype = new Label();
            cbbHwType = new ComboBox();
            lblBaudrate = new Label();
            cbbBaudrates = new ComboBox();
            btnHwRefresh = new Button();
            label1 = new Label();
            lbxInfo = new ListBox();
            timer1 = new System.Windows.Forms.Timer(components);
            tmrRead = new System.Windows.Forms.Timer(components);
            lstMessages = new ListView();
            clhType = new ColumnHeader();
            clhID = new ColumnHeader();
            clhLength = new ColumnHeader();
            clhCount = new ColumnHeader();
            clhRcvTime = new ColumnHeader();
            clhData = new ColumnHeader();
            tmrDisplay = new System.Windows.Forms.Timer(components);
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(chbShowPeriod);
            groupBox1.Controls.Add(rdbManual);
            groupBox1.Controls.Add(rdbEvent);
            groupBox1.Controls.Add(rdbTimer);
            groupBox1.Controls.Add(chbCanFD);
            groupBox1.Controls.Add(txtBitrate);
            groupBox1.Controls.Add(btnRelease);
            groupBox1.Controls.Add(btnIntialize);
            groupBox1.Controls.Add(lblInterrupt);
            groupBox1.Controls.Add(cbbInterrupt);
            groupBox1.Controls.Add(lblIOPort);
            groupBox1.Controls.Add(cbbIO);
            groupBox1.Controls.Add(lblHardwaretype);
            groupBox1.Controls.Add(cbbHwType);
            groupBox1.Controls.Add(lblBaudrate);
            groupBox1.Controls.Add(cbbBaudrates);
            groupBox1.Controls.Add(btnHwRefresh);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(0, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(1282, 235);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "groupBox1";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(29, 64);
            label2.Name = "label2";
            label2.Size = new Size(38, 15);
            label2.TabIndex = 17;
            label2.Text = "label2";
            // 
            // chbShowPeriod
            // 
            chbShowPeriod.AutoSize = true;
            chbShowPeriod.Checked = true;
            chbShowPeriod.CheckState = CheckState.Checked;
            chbShowPeriod.Location = new Point(491, 211);
            chbShowPeriod.Name = "chbShowPeriod";
            chbShowPeriod.Size = new Size(136, 19);
            chbShowPeriod.TabIndex = 16;
            chbShowPeriod.Text = "Timestamp as period";
            chbShowPeriod.UseVisualStyleBackColor = true;
            chbShowPeriod.CheckedChanged += chbShowPeriod_CheckedChanged;
            // 
            // rdbManual
            // 
            rdbManual.AutoSize = true;
            rdbManual.Location = new Point(328, 210);
            rdbManual.Name = "rdbManual";
            rdbManual.Size = new Size(97, 19);
            rdbManual.TabIndex = 15;
            rdbManual.Text = "Read  Manual";
            rdbManual.UseVisualStyleBackColor = true;
            rdbManual.CheckedChanged += rdbTimer_CheckedChanged_1;
            // 
            // rdbEvent
            // 
            rdbEvent.AutoSize = true;
            rdbEvent.Location = new Point(156, 210);
            rdbEvent.Name = "rdbEvent";
            rdbEvent.Size = new Size(124, 19);
            rdbEvent.TabIndex = 15;
            rdbEvent.Text = "Read using a event";
            rdbEvent.UseVisualStyleBackColor = true;
            rdbEvent.CheckedChanged += rdbTimer_CheckedChanged_1;
            // 
            // rdbTimer
            // 
            rdbTimer.AutoSize = true;
            rdbTimer.Checked = true;
            rdbTimer.Location = new Point(6, 210);
            rdbTimer.Name = "rdbTimer";
            rdbTimer.Size = new Size(125, 19);
            rdbTimer.TabIndex = 15;
            rdbTimer.TabStop = true;
            rdbTimer.Text = "Read using a Timer";
            rdbTimer.UseVisualStyleBackColor = true;
            rdbTimer.CheckedChanged += rdbTimer_CheckedChanged_1;
            // 
            // chbCanFD
            // 
            chbCanFD.AutoSize = true;
            chbCanFD.Location = new Point(919, 19);
            chbCanFD.Name = "chbCanFD";
            chbCanFD.Size = new Size(70, 19);
            chbCanFD.TabIndex = 14;
            chbCanFD.Text = "CAN-FD";
            chbCanFD.UseVisualStyleBackColor = true;
            chbCanFD.CheckedChanged += chbCanFD_CheckedChanged;
            // 
            // txtBitrate
            // 
            txtBitrate.Location = new Point(603, 109);
            txtBitrate.Multiline = true;
            txtBitrate.Name = "txtBitrate";
            txtBitrate.Size = new Size(297, 72);
            txtBitrate.TabIndex = 13;
            txtBitrate.TextChanged += txtBitrate_TextChanged;
            // 
            // btnRelease
            // 
            btnRelease.Location = new Point(919, 109);
            btnRelease.Name = "btnRelease";
            btnRelease.Size = new Size(193, 23);
            btnRelease.TabIndex = 11;
            btnRelease.Text = "Release";
            btnRelease.UseVisualStyleBackColor = true;
            btnRelease.Click += btnRelease_Click;
            // 
            // btnIntialize
            // 
            btnIntialize.Location = new Point(919, 61);
            btnIntialize.Name = "btnIntialize";
            btnIntialize.Size = new Size(193, 23);
            btnIntialize.TabIndex = 11;
            btnIntialize.Text = "Initialize coonect to hardware";
            btnIntialize.UseVisualStyleBackColor = true;
            btnIntialize.Click += btnInit_Click;
            // 
            // lblInterrupt
            // 
            lblInterrupt.AutoSize = true;
            lblInterrupt.Location = new Point(780, 19);
            lblInterrupt.Name = "lblInterrupt";
            lblInterrupt.Size = new Size(53, 15);
            lblInterrupt.TabIndex = 10;
            lblInterrupt.Text = "Interrupt";
            // 
            // cbbInterrupt
            // 
            cbbInterrupt.FormattingEnabled = true;
            cbbInterrupt.Items.AddRange(new object[] { "3", "4", "5", "7", "9", "10", "11", "12", "15" });
            cbbInterrupt.Location = new Point(780, 63);
            cbbInterrupt.Name = "cbbInterrupt";
            cbbInterrupt.Size = new Size(121, 23);
            cbbInterrupt.TabIndex = 9;
            // 
            // lblIOPort
            // 
            lblIOPort.AutoSize = true;
            lblIOPort.Location = new Point(604, 30);
            lblIOPort.Name = "lblIOPort";
            lblIOPort.Size = new Size(49, 15);
            lblIOPort.TabIndex = 8;
            lblIOPort.Text = "I/O Port";
            // 
            // cbbIO
            // 
            cbbIO.FormattingEnabled = true;
            cbbIO.Items.AddRange(new object[] { "0100", "0120", "0140", "0200", "0220", "0240", "0260", "0278", "0280", "02A0", "02C0", "02E0", "02E8", "02F8", "0300", "0320", "0340", "0360", "0378", "0380", "03BC", "03E0", "03E8", "03F8" });
            cbbIO.Location = new Point(604, 63);
            cbbIO.Name = "cbbIO";
            cbbIO.Size = new Size(121, 23);
            cbbIO.TabIndex = 7;
            cbbIO.SelectedIndexChanged += cbbIO_SelectedIndexChanged;
            // 
            // lblHardwaretype
            // 
            lblHardwaretype.AutoSize = true;
            lblHardwaretype.Location = new Point(446, 30);
            lblHardwaretype.Name = "lblHardwaretype";
            lblHardwaretype.Size = new Size(81, 15);
            lblHardwaretype.TabIndex = 6;
            lblHardwaretype.Text = "Hardwaretype";
            // 
            // cbbHwType
            // 
            cbbHwType.FormattingEnabled = true;
            cbbHwType.Items.AddRange(new object[] { "ISA-82C200", "ISA-SJA1000", "ISA-PHYTEC", "DNG-82C200", "DNG-82C200 EPP", "DNG-SJA1000", "DNG-SJA1000 EPP" });
            cbbHwType.Location = new Point(446, 62);
            cbbHwType.Name = "cbbHwType";
            cbbHwType.Size = new Size(121, 23);
            cbbHwType.TabIndex = 5;
            cbbHwType.SelectedIndexChanged += cbbHwType_SelectedIndexChanged;
            // 
            // lblBaudrate
            // 
            lblBaudrate.AutoSize = true;
            lblBaudrate.Location = new Point(288, 30);
            lblBaudrate.Name = "lblBaudrate";
            lblBaudrate.Size = new Size(54, 15);
            lblBaudrate.TabIndex = 1;
            lblBaudrate.Text = "Baudrate";
            // 
            // cbbBaudrates
            // 
            cbbBaudrates.FormattingEnabled = true;
            cbbBaudrates.Items.AddRange(new object[] { "1 MBit/sec", "800 kBit/s", "500 kBit/sec", "250 kBit/sec", "125 kBit/sec", "100 kBit/sec", "95,238 kBit/s", "83,333 kBit/s", "50 kBit/sec", "47,619 kBit/s", "33,333 kBit/s", "20 kBit/sec", "10 kBit/sec", "5 kBit/sec" });
            cbbBaudrates.Location = new Point(288, 63);
            cbbBaudrates.Name = "cbbBaudrates";
            cbbBaudrates.Size = new Size(121, 23);
            cbbBaudrates.TabIndex = 4;
            cbbBaudrates.SelectedIndexChanged += cbbBaudrates_SelectedIndexChanged;
            // 
            // btnHwRefresh
            // 
            btnHwRefresh.Location = new Point(180, 62);
            btnHwRefresh.Name = "btnHwRefresh";
            btnHwRefresh.Size = new Size(75, 23);
            btnHwRefresh.TabIndex = 3;
            btnHwRefresh.Text = "refresh";
            btnHwRefresh.UseVisualStyleBackColor = true;
            btnHwRefresh.Click += btnHwRefresh_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(26, 30);
            label1.Name = "label1";
            label1.Size = new Size(105, 15);
            label1.TabIndex = 1;
            label1.Text = "Hardware Selected";
            // 
            // lbxInfo
            // 
            lbxInfo.FormattingEnabled = true;
            lbxInfo.ItemHeight = 15;
            lbxInfo.Location = new Point(12, 332);
            lbxInfo.Name = "lbxInfo";
            lbxInfo.Size = new Size(250, 94);
            lbxInfo.TabIndex = 1;
            // 
            // tmrRead
            // 
            tmrRead.Interval = 50;
            tmrRead.Tick += tmrRead_Tick;
            // 
            // lstMessages
            // 
            lstMessages.Columns.AddRange(new ColumnHeader[] { clhType, clhID, clhLength, clhCount, clhRcvTime, clhData });
            lstMessages.Location = new Point(420, 329);
            lstMessages.Name = "lstMessages";
            lstMessages.Size = new Size(428, 97);
            lstMessages.TabIndex = 2;
            lstMessages.UseCompatibleStateImageBehavior = false;
            lstMessages.SelectedIndexChanged += lstMessages_SelectedIndexChanged;
            // 
            // tmrDisplay
            // 
            tmrDisplay.Tick += tmrDisplay_Tick;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1294, 450);
            Controls.Add(lstMessages);
            Controls.Add(lbxInfo);
            Controls.Add(groupBox1);
            FormBorderStyle = FormBorderStyle.None;
            MaximizeBox = false;
            MdiChildrenMinimizedAnchorBottom = false;
            MinimizeBox = false;
            Name = "Form2";
            ShowInTaskbar = false;
            Text = "Form2";
            Load += Form2_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label label1;
        private ComboBox cbbBaudrates;
        private Button btnHwRefresh;
        private Label lblBaudrate;
        private Label lblHardwaretype;
        private ComboBox cbbHwType;
        private ComboBox cbbIO;
        private Label lblIOPort;
        private Label lblInterrupt;
        private ComboBox cbbInterrupt;
        private Button btnIntialize;
        private TextBox txtBitrate;
        private ListBox lbxInfo;
        private CheckBox chbCanFD;
        private RadioButton rdbTimer;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer tmrRead;
        private ListView lstMessages;
        private ColumnHeader clhType;
        private ColumnHeader clhID;
        private ColumnHeader clhLength;
        private ColumnHeader clhCount;
        private ColumnHeader clhRcvTime;
        private ColumnHeader clhData;
        private CheckBox chbShowPeriod;
        private RadioButton rdbManual;
        private RadioButton rdbEvent;
        private Button btnRelease;
        private System.Windows.Forms.Timer tmrDisplay;
        private Label label2;
    }
}