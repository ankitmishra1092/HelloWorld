﻿namespace WinFormsTestApp
{
    partial class CarMakerMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel3 = new Panel();
            treeView1 = new TreeView();
            panel2 = new Panel();
            menuStripTop = new MenuStrip();
            systemToolStripMenuItem = new ToolStripMenuItem();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            menuStripTop.SuspendLayout();
            tabControl1.SuspendLayout();
            SuspendLayout();
            // 
            // panel3
            // 
            panel3.BackColor = SystemColors.ControlLight;
            panel3.Controls.Add(treeView1);
            panel3.Location = new Point(3, 45);
            panel3.Name = "panel3";
            panel3.Size = new Size(225, 1044);
            panel3.TabIndex = 28;
            // 
            // treeView1
            // 
            treeView1.Dock = DockStyle.Left;
            treeView1.Location = new Point(0, 0);
            treeView1.Name = "treeView1";
            treeView1.Size = new Size(211, 1044);
            treeView1.TabIndex = 26;
            //treeView1.DrawNode += treeView1_DrawNode;
            treeView1.AfterSelect += treeView1_AfterSelect;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.ActiveCaption;
            panel2.Controls.Add(menuStripTop);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(1466, 36);
            panel2.TabIndex = 29;
            // 
            // menuStripTop
            // 
            menuStripTop.Items.AddRange(new ToolStripItem[] { systemToolStripMenuItem });
            menuStripTop.Location = new Point(0, 0);
            menuStripTop.Name = "menuStripTop";
            menuStripTop.Size = new Size(1466, 24);
            menuStripTop.TabIndex = 25;
            menuStripTop.Text = "menuStrip1";
            // 
            // systemToolStripMenuItem
            // 
            systemToolStripMenuItem.Margin = new Padding(0, 0, 10, 0);
            systemToolStripMenuItem.Name = "systemToolStripMenuItem";
            systemToolStripMenuItem.Size = new Size(73, 20);
            systemToolStripMenuItem.Text = "Car Maker";
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Location = new Point(234, 45);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1680, 1044);
            tabControl1.TabIndex = 30;
            // 
            // tabPage1
            // 
            tabPage1.Location = new Point(4, 24);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(1672, 1016);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Car Maker Home";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // CarMakerMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1466, 696);
            Controls.Add(tabControl1);
            Controls.Add(panel2);
            Controls.Add(panel3);
            Name = "CarMakerMenu";
            Text = "CarMakerMenu";
            Load += CarMakerMenu_Load;
            panel3.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            menuStripTop.ResumeLayout(false);
            menuStripTop.PerformLayout();
            tabControl1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel3;
        private TreeView treeView1;
        private Panel panel2;
        private MenuStrip menuStripTop;
        private ToolStripMenuItem systemToolStripMenuItem;
        private TabControl tabControl1;
        private TabPage tabPage1;
    }
}